import {
  AwaError, DEFAULT_DISCLOSURE, DEFAULT_ENGAGEMENT, DEFAULT_FOLLOW_UP, DEFAULT_OUTCOMES,
  WriteQueue, canConnectCrm, canGoLive,
  type Clock, type TenantConfig, type TenantState, systemClock,
} from '@detent/awa-core';
import type { AuditLog } from '@detent/awa-audit';
import { DEFAULT_OBJECTIONS, DEFAULT_QUALIFICATION_MODEL } from '@detent/awa-agent';
import { DEFAULT_HIGH_RISK_TOPICS } from '@detent/awa-policy';

/**
 * Tenant management and provisioning (section 23.4).
 *
 * The two lifecycle gates are enforced here and cannot be configured away: no
 * CRM connection before a DPA record exists, and no live traffic before a
 * field-mapping dry run has been accepted by the tenant. Both are gates, not
 * suggestions, and both are the kind of control a DPO asks to see evidence of.
 */
const LIFECYCLE: Readonly<Record<TenantState, readonly TenantState[]>> = {
  REGISTERED: ['DPA_SIGNED'],
  DPA_SIGNED: ['CRM_CONNECTED'],
  CRM_CONNECTED: ['MAPPED'],
  MAPPED: ['TEST_MODE'],
  TEST_MODE: ['LIVE'],
  LIVE: ['DEGRADED', 'SUSPENDED'],
  DEGRADED: ['LIVE', 'SUSPENDED'],
  SUSPENDED: ['OFFBOARDING', 'LIVE'],
  OFFBOARDING: [],
};

export interface CreateTenantInput {
  readonly tenantId: string;
  readonly name: string;
  readonly connector: string;
  readonly residency?: TenantConfig['residency'];
  readonly homeJurisdiction?: TenantConfig['homeJurisdiction'];
  readonly serviceCatalogue?: readonly string[];
  readonly outboundAllowlist?: readonly string[];
}

/**
 * Somewhere a tenant configuration is kept beyond this process.
 *
 * The store stays synchronous, because it is read on every conversation turn
 * and making that path asynchronous would spread through the platform for no
 * gain. Durability is added around it: every change is written through, and
 * the store is filled from the archive at boot.
 */
export interface TenantArchive {
  save(config: TenantConfig): Promise<void>;
  loadAll(): Promise<readonly TenantConfig[]>;
}

export class TenantStore {
  private readonly tenants = new Map<string, TenantConfig>();
  private readonly writes = new WriteQueue();

  constructor(
    private readonly audit: AuditLog,
    private readonly clock: Clock = systemClock,
    private readonly archive?: TenantArchive,
  ) {}

  /**
   * Whether a tenant exists, without throwing if it does not.
   *
   * `get` throws, which is right where a missing tenant is a fault. Seeding is
   * the case where absence is the ordinary answer and asking must not be an
   * error.
   */
  has(tenantId: string): boolean {
    return this.tenants.has(tenantId);
  }

  /** Fills the store from the archive. Called once at boot, before serving. */
  async rehydrate(): Promise<number> {
    if (!this.archive) return 0;
    const stored = await this.archive.loadAll();
    for (const config of stored) this.tenants.set(config.tenantId, config);
    return stored.length;
  }

  /**
   * Writes a configuration through to the archive, if there is one.
   *
   * Reported rather than swallowed on failure: a tenant that is live in this
   * process but unsaved disappears at the next restart, taking its knowledge
   * with it, and does so with no warning at the time it mattered.
   */
  private persist(config: TenantConfig): void {
    if (!this.archive) return;
    const archive = this.archive;
    // Queued per tenant. A lifecycle runs several transitions in a row, and
    // unordered writes can leave the database showing an earlier state than
    // the one the tenant is actually in, which the table's own constraints
    // may then reject, or worse, accept.
    this.writes.run(config.tenantId, () => archive.save(config), (error: unknown) => {
      console.error(
        `Tenant archive: failed to save ${config.tenantId}. It is live in this `
        + 'process and will be lost on restart. '
        + String(error instanceof Error ? error.message : error),
      );
    });
  }

  /** Waits for every queued write. For shutdown, and for tests. */
  async flush(): Promise<void> {
    await this.writes.drain();
  }

  create(input: CreateTenantInput): TenantConfig {
    if (this.tenants.has(input.tenantId)) {
      throw new AwaError({ kind: 'CONFLICT', message: `tenant ${input.tenantId} already exists` });
    }
    const config: TenantConfig = {
      tenantId: input.tenantId,
      name: input.name,
      version: 1,
      state: 'REGISTERED',
      residency: input.residency ?? 'UK',
      homeJurisdiction: input.homeJurisdiction ?? 'UK',
      connector: input.connector,
      promptVersion: 'prompt-2026.09.1',
      policyVersion: 'policy-2026.09.1',
      modelVersion: 'model-pinned-2026.09',
      disclosure: DEFAULT_DISCLOSURE,
      priceList: [],
      serviceCatalogue: input.serviceCatalogue ?? [],
      qualification: DEFAULT_QUALIFICATION_MODEL,
      escalation: {
        confidenceFloor: 0.65,
        negativeSentimentTurns: 2,
        highRiskTopics: DEFAULT_HIGH_RISK_TOPICS,
      },
      objections: DEFAULT_OBJECTIONS,
      spendCaps: {
        monthlyPence: 50_000,
        warnAtFraction: 0.7,
        degradeToTextAtFraction: 0.9,
        maxConcurrentVoice: 5,
        maxConversationsPerMonth: 5_000,
      },
      retention: { transcriptDays: 90, voiceRecordingDays: 30, leadPersonalDataDays: 730, auditDays: 2_555 },
      recording: { enabled: false, transcriptionEnabled: false, attachTranscriptToCrm: false, attachAudioToCrm: false },
      killSwitch: 'OFF',
      outboundAllowlist: input.outboundAllowlist ?? [],
      requireApprovalForOpportunity: true,
      playbookVersion: 0,
      // Every new tenant starts in dry-run. Writes are real and diffable but
      // land in a staging ledger until the tenant accepts the diff (FR-036).
      dryRun: true,
      followUp: DEFAULT_FOLLOW_UP,
      engagement: DEFAULT_ENGAGEMENT,
      outcomes: DEFAULT_OUTCOMES,
    };
    this.tenants.set(config.tenantId, config);
    this.persist(config);
    return config;
  }

  get(tenantId: string): TenantConfig {
    const config = this.tenants.get(tenantId);
    if (!config) throw new AwaError({ kind: 'TENANT_NOT_FOUND', message: `tenant ${tenantId} not found` });
    return config;
  }

  list(): TenantConfig[] { return [...this.tenants.values()]; }

  /** Every tenant id, for the stores that must be read one tenant at a time. */
  ids(): readonly string[] { return [...this.tenants.keys()]; }

  /**
   * Update configuration. The version increments on every change so that a
   * conversation can be replayed against the exact configuration that produced
   * it, and the AI disclosure cannot be turned off (section 25.4).
   */
  update(tenantId: string, patch: Partial<TenantConfig>, actor: string): TenantConfig {
    const current = this.get(tenantId);

    if (patch.disclosure !== undefined) {
      const text = patch.disclosure.text?.trim() ?? '';
      const voice = patch.disclosure.voiceText?.trim() ?? '';
      if (text.length < 20 || voice.length < 20) {
        // Editable for tone; not removable. An empty or token disclosure is a
        // disabled disclosure by another name.
        throw new AwaError({
          kind: 'POLICY_DENIED',
          message: 'the AI disclosure cannot be removed or reduced below a meaningful statement',
        });
      }
    }
    if ('state' in patch) {
      throw new AwaError({ kind: 'POLICY_DENIED', message: 'tenant state changes go through transition(), not update()' });
    }

    const next: TenantConfig = { ...current, ...patch, state: current.state, version: current.version + 1 };
    this.tenants.set(tenantId, next);
    this.persist(next);
    void this.audit.write({
      tenantId, type: 'policy_allowed', correlationId: `cfg_${this.clock.nowMs()}`,
      actor: actor === 'platform' ? 'platform_admin' : 'tenant_admin',
      payload: { change: 'config_updated', fields: Object.keys(patch), version: next.version },
    });
    return next;
  }

  transition(tenantId: string, to: TenantState, actor: string): TenantConfig {
    const current = this.get(tenantId);
    if (!LIFECYCLE[current.state].includes(to)) {
      throw new AwaError({
        kind: 'POLICY_DENIED',
        message: `illegal tenant transition ${current.state} -> ${to}`,
      });
    }
    if (to === 'CRM_CONNECTED' && !canConnectCrm(current)) {
      throw new AwaError({ kind: 'POLICY_DENIED', message: 'no CRM connection before a signed DPA record exists' });
    }
    if (to === 'LIVE' && !canGoLive({ ...current, state: 'TEST_MODE' })) {
      throw new AwaError({ kind: 'POLICY_DENIED', message: 'no live traffic before the field-mapping dry run is accepted' });
    }

    const next: TenantConfig = { ...current, state: to, version: current.version + 1 };
    this.tenants.set(tenantId, next);
    this.persist(next);
    void this.audit.write({
      tenantId, type: 'policy_allowed', correlationId: `lifecycle_${this.clock.nowMs()}`,
      actor: actor === 'platform' ? 'platform_admin' : 'tenant_admin',
      payload: { change: 'state', from: current.state, to },
    });
    return next;
  }

  recordDpa(tenantId: string, reference: string): TenantConfig {
    const current = this.get(tenantId);
    const next: TenantConfig = {
      ...current,
      dpaSignedAt: this.clock.iso(),
      version: current.version + 1,
    };
    this.tenants.set(tenantId, next);
    this.persist(next);
    void this.audit.write({
      tenantId, type: 'policy_allowed', correlationId: `dpa_${this.clock.nowMs()}`,
      actor: 'tenant_admin', payload: { change: 'dpa_recorded', reference },
    });
    return this.transition(tenantId, 'DPA_SIGNED', 'tenant');
  }

  acceptFieldMapping(tenantId: string): TenantConfig {
    const current = this.get(tenantId);
    const next: TenantConfig = { ...current, fieldMappingAcceptedAt: this.clock.iso(), version: current.version + 1 };
    this.tenants.set(tenantId, next);
    this.persist(next);
    return next;
  }
}
