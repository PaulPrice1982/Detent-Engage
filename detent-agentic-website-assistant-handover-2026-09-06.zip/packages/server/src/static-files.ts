import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { join, normalize, extname, sep } from 'node:path';
import type { IncomingMessage, ServerResponse } from 'node:http';

/**
 * Static asset serving.
 *
 * Deliberately minimal and deliberately paranoid. The API is the product's
 * security surface; this exists so a browser pointed at the service gets a page
 * rather than a JSON 404. It serves only from directories the caller names, it
 * never follows a path out of them, and it never guesses a content type it does
 * not recognise.
 */
export interface StaticMount {
  /** URL prefix, e.g. `/widget`. Use `''` to mount at the root. */
  readonly prefix: string;
  /** Absolute directory on disk. */
  readonly dir: string;
}

const TYPES: Readonly<Record<string, string>> = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  // Recorded demonstrations. The list is an allowlist rather than a lookup
  // with a fallback: a file whose extension is not here is not served at all,
  // so an unexpected file dropped into a public directory cannot be handed to
  // a browser with a type that makes it executable.
  '.webm': 'video/webm',
  '.mp4': 'video/mp4',
};

/**
 * Resolves a URL path against a mount, or returns undefined if it does not
 * belong to that mount or tries to escape it.
 */
export function resolveStaticPath(mount: StaticMount, urlPath: string): string | undefined {
  if (mount.prefix && !urlPath.startsWith(mount.prefix + '/') && urlPath !== mount.prefix) {
    return undefined;
  }
  let relative = urlPath.slice(mount.prefix.length);
  if (relative === '' || relative === '/') relative = '/index.html';

  let decoded: string;
  try {
    decoded = decodeURIComponent(relative);
  } catch {
    return undefined;
  }
  // A NUL byte truncates a path in some syscalls; refuse rather than normalise.
  if (decoded.includes('\0')) return undefined;

  // Reject any parent-directory segment outright, before normalising.
  //
  // Normalising an absolute path silently *clamps* a traversal at the root , 
  // `/../secrets` becomes `/secrets`, which then joins to a real file inside the
  // mount. That is safe but surprising, and a security surface should not rely
  // on a surprise. No browser sends `..` in a legitimate asset request, so
  // refusing costs nothing and makes the guarantee readable: a served path is
  // exactly the path that was asked for.
  if (decoded.split(/[\\/]/).includes('..')) return undefined;

  const normalised = normalize(decoded);

  const full = join(mount.dir, normalised);
  // Belt and braces: the joined path must still sit inside the mount.
  if (full !== mount.dir && !full.startsWith(mount.dir.endsWith(sep) ? mount.dir : mount.dir + sep)) {
    return undefined;
  }
  return full;
}

/**
 * Attempts to serve a static file. Returns true if it wrote a response.
 *
 * Only GET and HEAD are served: a static directory must never be reachable by a
 * method that implies a state change, even though nothing here writes.
 */
export async function serveStatic(
  mounts: readonly StaticMount[],
  request: IncomingMessage,
  response: ServerResponse,
  baseHeaders: Readonly<Record<string, string>>,
): Promise<boolean> {
  const method = request.method ?? 'GET';
  if (method !== 'GET' && method !== 'HEAD') return false;

  const urlPath = new URL(request.url ?? '/', 'http://localhost').pathname;

  for (const mount of mounts) {
    const file = resolveStaticPath(mount, urlPath);
    if (!file) continue;

    const type = TYPES[extname(file).toLowerCase()];
    if (!type) continue;

    let size: number;
    try {
      const info = await stat(file);
      if (!info.isFile()) continue;
      size = info.size;
    } catch {
      continue;
    }

    const headers = {
      ...baseHeaders,
      'content-type': type,
      'content-length': String(size),
      // Assets are versioned by deployment, not by filename, so they are not
      // cached. Correctness over bandwidth until there is a build hash.
      'cache-control': 'no-store',
    };
    if (method === 'HEAD') {
      response.writeHead(200, headers).end();
      return true;
    }
    response.writeHead(200, headers);
    createReadStream(file).pipe(response);
    return true;
  }
  return false;
}

export { join as joinPath };
