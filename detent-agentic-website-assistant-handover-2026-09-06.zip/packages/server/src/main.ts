/**
 * Development entry point.
 *
 * Boots a platform with the in-memory stores, one demo tenant on the sandbox
 * connector, and the HTTP gateway. Production wiring differs in exactly one
 * place, the store implementations passed to `new Platform(...)`, because
 * every store is behind an interface.
 *
 *   pnpm serve
 */
import { SandboxConnector } from '@detent/awa-connectors';
import { GroundedModelProvider } from '@detent/awa-agent';
import {
  Api, ApiKeyService, Platform, SITE_CSP, consoleElsewherePage, createHttpServer,
  notConfiguredPage, seedDetentKnowledge,
} from './index.js';
import {
  PostgresConnectionStore, PostgresConsentStore, PostgresOutcomeStore,
  PostgresSuppressionStore, PostgresUsageStore, PostgresWriteReceiptStore,
  credentialKeyProblem,
} from '@detent/awa-persistence';
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { MARKETING_COPY_REVISION } from './marketing-seed.js';
import { buildDevSites } from './dev-sites.js';
import {
  checkHosts, consoleIsElsewhere, hostConfigFrom, hostnameOf, isPlatformProbe,
  recognisedHosts, resolveSite, signInAliasFor, unrecognisedHostAnswer,
} from './host-routing.js';
import { robotsTxt, sitemapXml } from './seo.js';
import { senderFromEnvironment } from '@detent/awa-auth';
import {
  PostgresAuditStore, PostgresKnowledgeArchive, PostgresTenantArchive,
  databaseFromEnvironment, migrate,
} from '@detent/awa-persistence';

/**
 * Whether this is a deployed environment.
 *
 * Replit sets REPLIT_DEPLOYMENT in a deployment and not in the workspace;
 * NODE_ENV covers everything else. A deployment declines every development
 * convenience, because on the internet those conveniences are leaked
 * credentials.
 */
const deployed = process.env['REPLIT_DEPLOYMENT'] === '1'
  || process.env['NODE_ENV'] === 'production'
  || process.env['DETENT_DEPLOYED'] === 'true';

const port = Number(process.env['PORT'] ?? 8787);
// Bind to every interface by default. A loopback-only bind is unreachable from
// a container's preview proxy (Replit, Codespaces, Docker port mapping), which
// presents as "the preview is not loading" with a perfectly healthy process.
const host = process.env['HOST'] ?? '0.0.0.0';

// A rejection nobody handled ends the process with a bare stack trace, and a
// host reports that as "built successfully but failed to start". Naming it
// first costs one line and turns an unreadable restart into a fixable fault.
// The exit is kept, because a process that has already half started is not
// safe to serve from; what changes is that the log says why.
process.on('unhandledRejection', (reason: unknown) => {
  console.error('Detent stopped: an operation failed and nothing handled it.');
  console.error(reason instanceof Error ? (reason.stack ?? reason.message) : String(reason));
  process.exit(1);
});
process.on('uncaughtException', (error: Error) => {
  console.error('Detent stopped: an unexpected error reached the top of the process.');
  console.error(error.stack ?? error.message);
  process.exit(1);
});

// The two sites. Separate realms, separate cookies, separate login screens.
// They share this process only because a preview can show one port.
/**
 * The database, when DATABASE_URL is set.
 *
 * Migrations run at boot rather than as a separate step somebody has to
 * remember: a deployment that starts against a schema older than its code is a
 * deployment that half works, and that is harder to diagnose than one that
 * refuses.
 *
 * A deployment with no database refuses to start. In development it is a
 * warning, because a laptop losing its data on restart costs nothing.
 */
const here = dirname(fileURLToPath(import.meta.url));

/**
 * Reasons this deployment must not serve.
 *
 * Collected rather than thrown, so the operator is told all of them at once
 * instead of fixing one and discovering the next. Declared before anything that
 * can fail, because everything below appends to it rather than throwing: a
 * throw here restarts the process, the host calls that a crash loop, and the
 * operator is told only that the app will not start. Nothing between here and
 * the guard at the bottom of this file may exit.
 */
const refusals: string[] = [];

/** What went wrong, for an operator, without a stack trace. */
function reasonOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

/**
 * Serve the reason instead of the product.
 *
 * The alternative, exiting, makes the platform restart the process and call it
 * a crash loop, which tells the operator only that something is wrong. This
 * tells them what, in the browser they are already looking at. Every route
 * answers the same way, including the API, and nothing is stored.
 */
function serveRefusals(problems: readonly string[]): void {
  for (const reason of problems) console.error(`Not configured: ${reason}`);
  const body = notConfiguredPage({ problems: [...problems] });
  createServer((request: IncomingMessage, response: ServerResponse) => {
    const path = (request.url ?? '/').split('?')[0] ?? '/';
    const asJson = path === '/health' || path === '/healthz';
    // The platform routes traffic to this container only while its probe path
    // answers 200, and a page nobody can reach explains nothing to anybody. So
    // the probe gets a 200 carrying the explanation, and every other path gets
    // the 503 the state deserves. The header says what this is either way, so
    // a monitor reading more than the status code is not misled.
    const status = isPlatformProbe(path) ? 200 : 503;
    const headers = {
      'content-type': asJson
        ? 'application/json; charset=utf-8' : 'text/html; charset=utf-8',
      // Never cached. The next request after it is fixed must get the real app.
      'cache-control': 'no-store',
      'x-detent-status': 'not_configured',
      // A configuration state that will pass, not a fault: a monitor should
      // treat it as unavailable and come back.
      'retry-after': '60',
      // Nothing here should ever be indexed, and a deployment stuck in this
      // state for a day is exactly when a crawler would find it.
      'x-robots-tag': 'noindex, nofollow',
    };
    response.writeHead(status, headers).end(
      asJson ? JSON.stringify({ status: 'not_configured', reasons: problems }) : body,
    );
  }).listen(port, host, () => {
    console.error(
      `Detent is not configured and is answering 503 on ${host}:${port}. `
      + 'Open it in a browser to see what is missing.',
    );
  });
}

const configured = databaseFromEnvironment();
if (!configured && deployed) {
  refusals.push(
    'DATABASE_URL is not set. Every account, subscription, invoice and page would be held '
    + 'in memory and lost at the next restart. Add a PostgreSQL database to this app and it '
    + 'will be set for you.',
  );
}

/**
 * The database, once it has proved it works.
 *
 * Migrations run at boot rather than as a separate step somebody has to
 * remember: a deployment that starts against a schema older than its code is a
 * deployment that half works, and that is harder to diagnose than one that
 * refuses. A database that is set but unreachable, out of connections or
 * refusing the migration is the commonest deployment fault of all, and it must
 * produce the page above rather than a restart.
 */
let database = configured;
if (configured) {
  try {
    const applied = await migrate(configured, resolve(here, '../../../db/migrations'));
    console.log(applied.length > 0
      ? `  migrations       applied ${applied.join(', ')}`
      : '  migrations       up to date');
  } catch (error) {
    database = undefined;
    const detail = `The database is configured but could not be prepared: ${reasonOf(error)}`;
    if (deployed) {
      refusals.push(
        `${detail} Check that the database attached to this app is running and that `
        + 'DATABASE_URL points at it. Nothing has been written and no data has been lost.',
      );
    } else {
      console.error(`${detail}`);
      console.error('Continuing in memory. Data will be lost when this process stops.');
    }
  }
}

const crm = new SandboxConnector({ hasSeparateLeadObject: true });

/**
 * Durable CRM credentials, when there is a usable key to encrypt them with.
 *
 * A malformed key behaves exactly as a missing one: the connection is held in
 * memory, nothing is written in clear, and the boot banner says so in capital
 * letters. It is never a refusal.
 *
 * That distinction cost a working site. A bad key was treated as a refusal, on
 * the reasoning that somebody who set the secret meant credentials to be
 * encrypted and carrying on quietly would be the opposite of what they asked
 * for. The reasoning was right and the consequence was wrong: one mistyped
 * optional secret took down the marketing site, the customer app and the
 * console, none of which need that key for anything. The rule this file already
 * followed everywhere else is the correct one, and it applies here too: a
 * missing or unusable credential disables the feature it belongs to, loudly,
 * and takes nothing else with it.
 */
let credentialStore: PostgresConnectionStore | undefined;
let credentialNote = 'not stored, no DETENT_CREDENTIAL_KEY set';
const credentialKey = process.env['DETENT_CREDENTIAL_KEY'];
if (database && credentialKey) {
  const problem = credentialKeyProblem(credentialKey);
  if (problem) {
    // Printed as a warning at the top of the log, and again in the banner, so
    // it is seen whether somebody reads the start or the end of the output.
    console.warn('');
    console.warn(`  ${problem}`);
    console.warn('  Until it is corrected, CRM connections are kept in memory and every');
    console.warn('  customer reconnects after a deploy. Nothing else is affected and');
    console.warn('  nothing is stored in clear. The site is serving normally.');
    console.warn('');
    credentialNote = 'IN MEMORY, the key is not valid. See the warning above';
  } else {
    credentialStore = new PostgresConnectionStore(database, credentialKey, {
      onUndecryptable: (tenantId) => console.warn(
        `The stored CRM credential for ${tenantId} cannot be read with this `
        + 'DETENT_CREDENTIAL_KEY, so that tenant reads as not connected. If the key was '
        + 'rotated, restore the previous one or have the tenant reconnect their CRM.',
      ),
    });
    credentialNote = 'encrypted with DETENT_CREDENTIAL_KEY';
  }
} else if (database) {
  credentialNote = 'IN MEMORY, every customer reconnects their CRM after a deploy';
}
const platform = new Platform({
  // Answers from the tenant's approved knowledge and from nothing else. Swap
  // for a provider backed by a language model, which phrases the same
  // approved material rather than replacing it, and the rest of the platform
  // does not change.
  //
  // This is the honest default rather than a placeholder: a stub answering
  // every question with "what are you trying to solve?" demonstrates the
  // opposite of what the product claims.
  model: new GroundedModelProvider(),
  connectors: [crm],
  // Durable where a database is configured. The audit trail especially: a
  // hash chain proves nothing if it begins again at the last deploy.
  auditStore: database ? new PostgresAuditStore(database) : undefined,
  knowledgeArchive: database ? new PostgresKnowledgeArchive(database) : undefined,
  tenantArchive: database ? new PostgresTenantArchive(database) : undefined,
  // What the customer is billed from, what they consented to, what was written
  // to their CRM, and who asked not to be contacted. All of these were memory
  // only, so all of them were lost at every deploy and none of them agreed
  // between two instances of the same deployment.
  usageStore: database ? new PostgresUsageStore(database) : undefined,
  consentStore: database ? new PostgresConsentStore(database) : undefined,
  receiptStore: database ? new PostgresWriteReceiptStore(database) : undefined,
  outcomeStore: database ? new PostgresOutcomeStore(database) : undefined,
  suppressionStore: database ? new PostgresSuppressionStore(database) : undefined,
  // A customer's CRM token is the keys to their Salesforce, so it is stored
  // encrypted or not at all. With no key configured the connection stays in
  // memory and the boot banner says so: reconnecting after a deploy is a
  // nuisance, and a plaintext OAuth token in a database is an incident.
  connectionStore: credentialStore,
});

const TENANT = process.env['AWA_TENANT_ID'] ?? 't_demo';

let restoredTenants = 0;
let restoredChunks = 0;
let seededAnswers = 0;
try {
  // Filled from the database before anything serves. A restart that started
  // with an empty corpus would answer nothing, and would look from the outside
  // exactly like a customer who had never uploaded anything.
  restoredTenants = await platform.tenants.rehydrate();
  // The tenants first, because knowledge is read one tenant at a time: the
  // table is a customer's own material and its policy requires the reader to
  // name whose material it is asking for.
  restoredChunks = await platform.corpus.rehydrate(platform.tenants.ids());

  // Seeding, on a database that already holds the tenant, must not throw. This
  // is the same fault the console operator had: create() is right the first
  // time and fatal every time after.
  if (!platform.tenants.has(TENANT)) {
    platform.tenants.create({
      tenantId: TENANT,
      name: process.env['AWA_TENANT_NAME'] ?? 'Demo Ltd',
      connector: 'sandbox',
      serviceCatalogue: ['contract-review', 'revenue-recovery'],
      outboundAllowlist: (process.env['AWA_ALLOWLIST'] ?? '').split(',').filter(Boolean),
    });
    platform.tenants.recordDpa(TENANT, 'DPA-DEV');
    // The tenant has to be in the database before anything references it. The
    // store writes through on a queue, so creating a tenant and immediately
    // connecting its CRM raced the write and failed on the foreign key: "insert
    // or update on table crm_connection violates foreign key constraint". In
    // memory there is no such thing as later, which is why this only appeared
    // against a real database.
    await platform.tenants.flush();
    await platform.connectCrm(TENANT, 'sandbox', { kind: 'oauth2', accessToken: 'dev-token' });
    platform.tenants.transition(TENANT, 'CRM_CONNECTED', 'tenant');
    platform.tenants.transition(TENANT, 'MAPPED', 'tenant');
    platform.tenants.acceptFieldMapping(TENANT);
    platform.tenants.transition(TENANT, 'TEST_MODE', 'tenant');
    platform.tenants.transition(TENANT, 'LIVE', 'tenant');
    await platform.tenants.flush();
  }

  // Detent's assistant answers about Detent, from Detent's own approved
  // knowledge. Without this the assistant on the marketing site falls back to
  // "what are you trying to solve?", which demonstrates the opposite of what
  // the page it sits on argues.
  // Only when the corpus is empty for this tenant. Seeding unconditionally
  // against a durable corpus adds fourteen more copies at every restart, and a
  // corpus with fifteen of each answer retrieves worse, not better.
  seededAnswers = platform.corpus.all(TENANT).length === 0
    ? seedDetentKnowledge(platform.corpus, TENANT)
    : 0;
} catch (error) {
  refusals.push(
    `Stored data could not be read back at start-up: ${reasonOf(error)} The database `
    + 'answered the migration and then failed on a read, which usually means it went away '
    + 'mid-start or the schema does not match this release. Nothing has been deleted.',
  );
}

const keys = new ApiKeyService();
const api = new Api(platform, keys);

const widget = keys.issue(TENANT, 'widget');
const admin = keys.issue(TENANT, 'tenant_admin');
const platformAdmin = keys.issue('*platform*', 'platform_admin');

const hosts = hostConfigFrom(process.env, deployed);
// Refusing is right: a deployment that shares a hostname between the console
// and anything else has lost the separation the console depends on.
for (const problem of checkHosts(hosts, deployed)) refusals.push(problem.message);

// Everything below builds and starts the product. Any failure in it is served
// as the page above rather than thrown: a start-up fault the operator cannot
// read is a fault they cannot fix.
if (refusals.length > 0) {
  serveRefusals(refusals);
} else {
try {

const sites = await buildDevSites({
  database,
  audit: platform.audit,
  clock: platform.clock,
  sessionSecret: process.env['DETENT_SESSION_SECRET'],
  operatorEmail: process.env['DETENT_CONSOLE_EMAIL'],
  // Never a literal in source. Set DETENT_CONSOLE_PASSWORD in the host's
  // secret store; when it is unset a password is generated and printed once.
  operatorPassword: process.env['DETENT_CONSOLE_PASSWORD'],
  // A deployment is served over HTTPS, so Secure cookies are correct there and
  // wrong on a plain-HTTP preview, where the browser would silently drop them
  // and sign-in would appear to fail with no error anywhere. Following the
  // deployment by default gets both right without anyone having to remember.
  secureCookies: process.env['DETENT_SECURE_COOKIES']
    ? process.env['DETENT_SECURE_COOKIES'] === 'true'
    : deployed,
  // Reset links must be absolute, because they are followed from a mail client.
  // On a preview this is the repl's public URL; unset, links are relative and
  // will not work from an inbox, which the boot line says.
  baseUrl: process.env['DETENT_BASE_URL'] ?? `http://localhost:${process.env['PORT'] ?? 8787}`,
  emailSender: senderFromEnvironment(process.env),
  stripeSecretKey: process.env['STRIPE_SECRET_KEY'],
  stripeWebhookSecret: process.env['STRIPE_WEBHOOK_SECRET'],
  googleConfigured: Boolean(process.env['GOOGLE_CLIENT_ID'] && process.env['GOOGLE_CLIENT_SECRET']),
  appleConfigured: Boolean(process.env['APPLE_CLIENT_ID'] && process.env['APPLE_PRIVATE_KEY']),
  // The demo tenant's widget key, so the install page shows a real snippet.
  widgetKeyFor: () => widget.key,
  deployed,
  // Relative unless the customer area has a hostname of its own.
  //
  // This was the sign-in fault, and it was on the page rather than in the
  // routing. Without DETENT_APP_HOST every "Sign in" and "Start free" link on
  // the marketing site was written as http://localhost:8787/app/signin, which
  // on a visitor's phone means that visitor's own machine. The links went
  // nowhere for everybody who has ever opened the site, and the sign-in page
  // they pointed at was serving correctly the whole time, which is why curling
  // the path always looked fine.
  //
  // Empty means relative, so /app/signin resolves against whatever host served
  // the page: the platform hostname, a custom domain, or a laptop. An absolute
  // URL is written only when there is a real hostname to write, and then it is
  // needed, because the customer area is on a different domain from the
  // marketing site.
  appBaseUrl: process.env['DETENT_APP_HOST']
    ? `https://${process.env['DETENT_APP_HOST']}`
    : '/app',
  // Detent runs its own assistant on its own marketing site. A vendor who will
  // not is telling you something.
  assistant: {
    // Relative, because this is our own site. A customer's snippet carries the
    // absolute URL: their page is on their domain and has to point at ours , 
    // but ours is already here, and an absolute URL naming a different
    // spelling of this same host (localhost against 127.0.0.1, or a bare
    // domain against www) is refused by our own script-src and frame-src.
    apiBaseUrl: '',
    publicKey: widget.key,
    panelUrl: '/widget/panel.html',
  },
});



// Knowledge is read from an in-memory index, so a second instance of this
// deployment learns about an approval only when it next loads. Refreshing keeps
// the window to a minute instead of to a restart. Only where there is an
// archive to refresh from: with no database there is one process and one truth.
if (database) {
  platform.corpus.startRefreshing({
    intervalMs: Number(process.env['DETENT_KNOWLEDGE_REFRESH_MS'] ?? 60_000),
    tenants: () => platform.tenants.ids(),
    onError: (error) => console.warn(
      `Knowledge refresh failed, serving the index as it was: ${reasonOf(error)}`,
    ),
  });
}

const staticMounts = [
  { prefix: '/widget', dir: resolve(here, '../../widget/public') },
  { prefix: '', dir: resolve(here, '../public') },
];

const server = createHttpServer(api, {
  port,
  allowedOrigins: (process.env['AWA_ORIGINS'] ?? '*').split(',').filter(Boolean),
  staticMounts,
  sites: [
    {
      // One mount for all three sites: the hostname decides which, and a path
      // prefix is consulted only in development. In a deployment the console
      // is simply not reachable from the other domains.
      prefix: '',
      async handle(request) {
        // Answered before anything else, on every hostname, so it works on a
        // deployment, on the workspace preview, and on a hostname nothing is
        // configured for. It carries the two facts that were impossible to
        // establish from outside: which release is actually serving, and
        // whether the back office is reachable at this address.
        //
        // copyRevision is the build stamp. It cannot go stale the way a
        // hand-written version string does, because it is the same number the
        // copy release uses, and a build older than that mechanism does not
        // return the field at all. Comparing the live URL against the workspace
        // is then one curl each, rather than a screenshot and an argument.
        if (request.path === '/health') {
          return {
            status: 200,
            contentType: 'application/json; charset=utf-8',
            html: JSON.stringify({
              status: 'ok',
              killSwitch: platform.platformKillSwitch,
              copyRevision: MARKETING_COPY_REVISION,
              consoleHere:
                resolveSite(hosts, request.headers['host'], '/console')?.site === 'console',
              host: hostnameOf(request.headers['host']),
            }),
          };
        }
        const match = resolveSite(hosts, request.headers['host'], request.path);
        if (!match) {
          // A request on a hostname nothing is configured for. The visitor is
          // told nothing useful, naming the configured hosts here would hand
          // an attacker the map, but the operator gets a log line, because
          // the alternative is a 404 on every page with no explanation of why.
          // The platform's own health check arrives here, on its proxy's
          // hostname, and a 404 to it takes the whole deployment down. See
          // unrecognisedHostAnswer.
          const answer = unrecognisedHostAnswer(request.path);
          if (answer.status !== 200) {
            console.warn(
              `Unrecognised Host: ${hostnameOf(request.headers['host'])}, serving nothing. `
              + `Recognised: ${recognisedHosts(hosts).join(', ') || '(none configured)'}`,
            );
          }
          return { status: answer.status, html: answer.body, contentType: answer.contentType };
        }
        // The back office exists, on a hostname of its own, and this is not it.
        // Before this the request fell through to the marketing site and got its
        // 404, which says nothing about where the console went or how to reach
        // it while a new domain is still propagating.
        // A guessed sign-in address is sent where it was trying to go. Which
        // one depends on the host: on a console host it is the back office, and
        // anywhere else it is the customer's own account, because a customer
        // typing /login means their account and never our staff console.
        if (signInAliasFor(request.path)) {
          return {
            status: 303,
            redirect: match.site === 'console' ? '/console/signin' : '/app/signin',
          };
        }

        if (consoleIsElsewhere(hosts, request.path)) {
          return {
            status: 404,
            html: consoleElsewherePage(),
            csp: SITE_CSP,
          };
        }
        if (match.site === 'console') return sites.consoleRouter.handle(request);
        if (match.site === 'reseller') {
          return sites.resellerRouter.handle(request);
        }
        if (match.site === 'app') {
          // The customer area shows the install snippet and its own preview,
          // so it needs the same policy as the public site.
          const rendered = await sites.appRouter.handle(request);
          return rendered ? { ...rendered, csp: SITE_CSP } : rendered;
        }
        if (request.method !== 'GET' && request.method !== 'HEAD') return undefined;
        // The API falls through to its own handler.
        if (request.path.startsWith('/v1/')) return undefined;

        // Told to crawlers only where this hostname is the canonical one. On
        // any other, the site asks not to be indexed at all, so the platform
        // hostname does not compete with the custom domain for the same words.
        const canonicalHost = hosts.marketingHost ?? (hosts.platformHosts ?? [])[0];
        const thisHost = hostnameOf(request.headers['host']);
        const isCanonicalHost = !canonicalHost || thisHost === canonicalHost;
        const origin = `https://${canonicalHost ?? thisHost}`;

        if (request.path === '/robots.txt') {
          return { status: 200, html: robotsTxt(origin, isCanonicalHost), contentType: 'text/plain; charset=utf-8' };
        }
        if (request.path === '/sitemap.xml') {
          return {
            status: 200,
            html: sitemapXml(await sites.pages.list(), origin),
            contentType: 'application/xml; charset=utf-8',
          };
        }
        // Anything with a file extension is a file, and belongs to the static
        // handler. This was an allowlist of four directory prefixes, and every
        // asset that lives at the root fell outside it: /og-image.png,
        // /favicon.svg and /apple-touch-icon.png were all declared in the head
        // of every page and all three answered with the marketing 404. A social
        // preview with no image and a site with no favicon is most of what an
        // automated SEO check is looking at.
        //
        // A marketing slug never contains a dot, so the rule is the file name
        // itself rather than a list that has to be remembered.
        if (/\.[a-z0-9]+$/i.test(request.path)) return undefined;

        const rendered = await sites.marketing(request.path, {
          canonicalOrigin: origin,
          imageUrl: `${origin}/og-image.png`,
          // A page served on a hostname that is not the canonical one is asked
          // not to be indexed. The canonical tag says where the original is;
          // this says do not list the copy at all.
          indexable: isCanonicalHost,
        });
        // The public site runs the assistant, so it cannot carry the console's
        // no-script policy. Without this the loader is refused by the browser
        // and Detent's own site does not run the product it sells.
        return rendered ? { ...rendered, csp: SITE_CSP } : rendered;
      },
    },
  ],
});

// Without this, a port already in use raises an unhandled 'error' event: Node
// prints a stack trace and exits, and a host reports only that the app is not
// running. The commonest startup failure deserves the clearest message.
server.on('error', (error: NodeJS.ErrnoException) => {
  if (error.code === 'EADDRINUSE') {
    console.error(
      [
        `Port ${port} is already in use, so this server cannot start.`,
        '',
        'Almost always a previous run that did not shut down. Free the port:',
        `  npx --yes kill-port ${port}`,
        `  pkill -f 'packages/server/src/main.ts'`,
        '',
        `Or run alongside it on another port:  PORT=${port + 1} node tools/serve.mjs`,
      ].join('\n'),
    );
  } else if (error.code === 'EACCES') {
    console.error(`Not permitted to bind ${host}:${port}. Ports below 1024 need privileges.`);
  } else {
    console.error(`Could not start the server: ${error.message}`);
  }
  process.exit(1);
});

server.listen(port, host, () => {
  // Printed once, at boot, on a development server only. Keys are stored as
  // digests, so this is the only moment they exist in readable form.
  console.log(`Detent Agentic Website Assistant listening on ${host}:${port}`);
  console.log(`  open             http://localhost:${port}/`);
  console.log(`  back office      http://localhost:${port}/console`);
  console.log(`  customer app     http://localhost:${port}/app`);
  console.log(`  tenant           ${TENANT}`);
  // Printed always. A request arriving on a hostname that is not on this list
  // gets a 404 on every page, and comparing the browser's URL against it is
  // the fastest way to see why.
  console.log(`  hostnames        ${recognisedHosts(hosts).join(', ') || 'any (development)'}`);
  // Where the back office actually is, said plainly. The commonest way to lose
  // it is to set DETENT_CONSOLE_HOST for a domain whose DNS is not cut over
  // yet: the console then exists on a hostname nothing resolves to, /console on
  // the platform hostname is correctly a 404, and the symptom reported is "the
  // sign in page does not work", which names none of that.
  if (hosts.consoleHost) {
    console.log(`  back office at   https://${hosts.consoleHost}/`);
    if (!hosts.consoleOnPlatformHost && (hosts.platformHosts ?? []).length > 0) {
      console.log('                   and NOT on the platform hostname. Until that domain');
      console.log('                   resolves here, set DETENT_CONSOLE_ON_PLATFORM_HOST=true');
      console.log('                   to reach it at /console on the platform hostname.');
    }
  } else if ((hosts.platformHosts ?? []).length > 0 && !hosts.consoleOnPlatformHost && deployed) {
    console.log('  back office      NOT REACHABLE. Set DETENT_CONSOLE_HOST, or set');
    console.log('                   DETENT_CONSOLE_ON_PLATFORM_HOST=true to serve it at');
    console.log('                   /console on the platform hostname.');
  }
  console.log(database
    ? '  storage          Postgres, data survives a restart'
    : '  storage          IN MEMORY, everything is lost when this process stops');
  console.log(`  CRM credentials  ${credentialNote}`);
  console.log(sites.sessionsPersist
    ? '  sessions         survive a restart'
    : '  sessions         NOT KEPT across a restart. Everybody is signed out when this'
      + ' process stops. Set DETENT_SESSION_SECRET.');
  console.log(sites.paymentProviderName === 'stripe'
    ? '  payments         Stripe, real cards'
    : '  payments         SANDBOX, no card is ever charged. Set STRIPE_SECRET_KEY'
      + ' and STRIPE_WEBHOOK_SECRET.');
  if (database) {
    console.log(`  restored         ${restoredTenants} tenants, ${restoredChunks} knowledge chunks`);
  }
  console.log(`  own knowledge    ${seededAnswers} approved answers about Detent`);
  // Which pages this release changed, and which it deliberately did not. A
  // page somebody edited in the console keeps their words, and the operator is
  // told rather than left to wonder why a rewrite did not appear.
  for (const [slug, outcome] of Object.entries(sites.copy)) {
    const label = `  copy /${slug}`.padEnd(19);
    if (outcome === 'kept-edited') {
      console.log(`${label}edited in the console, so this release left it alone`);
    } else if (outcome !== 'current') {
      console.log(`${label}${outcome} from the copy shipped in this release`);
    }
  }
  if (deployed) {
    // Keys are printed on a development server so the demo can be driven from
    // a terminal. A deployment prints nothing: its logs are retained, shipped
    // to a log service and read by people who should not be handed an admin
    // key by scrolling.
    console.log('  keys             not printed in a deployment');
  } else {
    console.log(`  widget key       ${widget.key}`);
    console.log(`  tenant admin key ${admin.key}`);
    console.log(`  platform key     ${platformAdmin.key}`);
  }
  console.log('');
  console.log('  ---- console sign-in ----');
  if (sites.operatorConfigured) {
    // Printed in a deployment too. It is an address, not a credential, and a
    // sign-in that will not take is nearly always the address being a different
    // one from the address in the secret. Hiding it makes that unfindable.
    console.log(`  address          ${sites.operatorEmail}`);
    console.log('  password         (from DETENT_CONSOLE_PASSWORD)');
  } else {
    // Nothing is generated and nothing is written to disk. The secret is the
    // only place the password exists, which is the only arrangement that
    // survives a deployment security scan.
    console.log('  NOT CONFIGURED   set DETENT_CONSOLE_PASSWORD in your secrets,');
    console.log('                   then restart. The back office cannot be signed');
    console.log('                   into until you do; the customer app is unaffected.');
  }
  console.log('  ------------------------');
  console.log(`  email sender     ${sites.emailSender.name}`);
  if (sites.emailSender.name === 'console') {
    // Nothing is actually sent, so the reset link is printed instead. Said
    // plainly, because a flow that looks like it worked and sent nothing is
    // worse than one that fails.
    console.log('                   Emails are PRINTED HERE, not sent. Reset links');
    console.log('                   appear in this output. Configure a real sender');
    console.log('                   before launch.');
  }
  if (!process.env['DETENT_BASE_URL']) {
    console.log('  DETENT_BASE_URL  not set, reset links point at localhost and will');
    console.log('                   not work from a mail client. Set it to the public URL.');
  }
  if (!deployed) {
    console.log('');
    console.log(`  curl -s -XPOST localhost:${port}/v1/sessions -H "authorization: Bearer ${widget.key}" -H 'content-type: application/json' -d '{"jurisdiction":"UK"}'`);
  }
});
} catch (error) {
  // Deliberately does not guess whether this is a bad setting or a bad
  // release. It caught a console password of ten characters and called it a
  // fault in the release, which would have sent somebody looking in the wrong
  // place. The message it was given is nearly always the answer.
  serveRefusals([
    `Detent could not start: ${reasonOf(error)}`,
    'If that names a setting, correct it in your secrets and start again. If it '
    + 'does not, the logs for this deployment carry the detail.',
  ]);
}
}
