import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import type { Api, ApiRequest } from './api.js';
import { serveStatic, type StaticMount } from './static-files.js';

/**
 * HTTP transport.
 *
 * Thin by design: it reads the request, hands it to the router, and writes the
 * response. Every security decision, authentication, tenant binding, policy , 
 * happens in the router, so nothing here can be bypassed by reaching the
 * transport differently.
 */
export interface HttpServerOptions {
  readonly port?: number;
  readonly maxBodyBytes?: number;
  /** Origins permitted to call the session API from a browser. */
  readonly allowedOrigins?: readonly string[];
  /**
   * Directories served as static assets. Tried before the router, and only for
   * GET/HEAD against a real file with a known extension, so no API route can be
   * shadowed by a file on disk.
   */
  readonly staticMounts?: readonly StaticMount[];
  /**
   * Server-rendered sites, tried before static and before the router.
   *
   * Each is a separate site with its own path prefix: the operator back office
   * and the customer app share this transport and nothing else. A site handler
   * returning undefined declines the request and it falls through.
   */
  readonly sites?: readonly SiteMount[];
}

export interface SiteMount {
  readonly prefix: string;
  handle(request: {
    readonly method: string;
    readonly path: string;
    readonly query: Readonly<Record<string, string>>;
    readonly headers: Record<string, string | undefined>;
    readonly rawBody?: string;
    readonly rawBodyBuffer?: Buffer;
  }): Promise<{
    status: number;
    html?: string;
    redirect?: string;
    cookies?: readonly string[];
    /**
     * Content security policy for this response.
     *
     * Defaults to the console's, which forbids script entirely. That is right
     * for the back office and wrong for the public site: applied there it
     * blocked the assistant's own loader, so Detent's site could not run the
     * product it sells. A site that needs script says so here rather than the
     * strictest policy being relaxed for everybody.
     */
    csp?: string;
    /**
     * Overrides the content type.
     *
     * robots.txt and sitemap.xml are served by the site handler because they
     * are generated from its pages, but a crawler given robots.txt as
     * text/html may ignore it, and a sitemap that is not XML is not a sitemap.
     */
    contentType?: string;
  } | undefined>;
}

/**
 * The back office policy: no script at all, from anywhere.
 *
 * The console is server-rendered and needs none, so forbidding it outright
 * turns a whole class of injection into a browser error rather than a breach.
 */
export const CONSOLE_CSP =
  "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'";

/**
 * The public and customer policy.
 *
 * Script only from our own origin, which is where the assistant's loader
 * lives, and nothing inline, so an injected <script> still cannot run. The
 * panel is framed from the same origin, and media is served from it too.
 */
export const SITE_CSP = [
  "default-src 'none'",
  "script-src 'self'",
  "style-src 'unsafe-inline'",
  "img-src 'self' data:",
  "media-src 'self'",
  "font-src 'self'",
  "connect-src 'self'",
  "frame-src 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
  "base-uri 'none'",
].join('; ');

export function createHttpServer(api: Api, options: HttpServerOptions = {}): Server {
  const maxBodyBytes = options.maxBodyBytes ?? 256 * 1024;

  const staticMounts = options.staticMounts ?? [];
  const sites = options.sites ?? [];

  return createServer((request, response) => {
    void handle(api, request, response, maxBodyBytes, options.allowedOrigins ?? ['*'],
      staticMounts, sites);
  });
}

async function handle(
  api: Api,
  request: IncomingMessage,
  response: ServerResponse,
  maxBodyBytes: number,
  allowedOrigins: readonly string[],
  staticMounts: readonly StaticMount[],
  sites: readonly SiteMount[],
): Promise<void> {
  const origin = request.headers.origin;
  const allowOrigin = allowedOrigins.includes('*')
    ? '*'
    : (origin && allowedOrigins.includes(origin) ? origin : '');

  const headers: Record<string, string> = {
    'content-type': 'application/json; charset=utf-8',
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'no-referrer',
    'cache-control': 'no-store',
  };
  if (allowOrigin) {
    headers['access-control-allow-origin'] = allowOrigin;
    headers['access-control-allow-headers'] = 'authorization, content-type';
    headers['access-control-allow-methods'] = 'GET, POST, PATCH, OPTIONS';
    headers['vary'] = 'origin';
  }

  if (request.method === 'OPTIONS') {
    response.writeHead(204, headers).end();
    return;
  }

  const url = new URL(request.url ?? '/', 'http://localhost');
  const siteMatches = sites.some((site) => url.pathname.startsWith(site.prefix));

  // A site handles forms, so it needs the body. Read it once, before the loop,
  // and only when a site could actually claim the request.
  let siteBody: string | undefined;
  let siteBytes: Buffer | undefined;
  if (siteMatches && request.method === 'POST') {
    try {
      // A site may accept a file upload, which is larger than an API request
      // and binary. Read it once as bytes; the string form is for the ordinary
      // urlencoded case.
      siteBytes = await readBodyBytes(request, MAX_UPLOAD_BYTES);
      siteBody = siteBytes.toString('utf8');
    } catch {
      response.writeHead(413, headers).end(JSON.stringify({ error: 'SCHEMA_INVALID' }));
      return;
    }
  }

  for (const site of sites) {
    if (!url.pathname.startsWith(site.prefix)) continue;
    const rendered = await site.handle({
      method: request.method ?? 'GET',
      path: url.pathname,
      query: Object.fromEntries(url.searchParams),
      headers: request.headers as Record<string, string | undefined>,
      rawBody: siteBody,
      rawBodyBuffer: siteBytes,
    });
    if (rendered) {
      const siteHeaders: Record<string, string | string[]> = {
        ...headers,
        'content-type': rendered.contentType ?? 'text/html; charset=utf-8',
        // The console shows money and takes irreversible actions. It is never
        // framed, never sniffed, and never cached by an intermediary.
        'x-frame-options': 'DENY',
        'content-security-policy': rendered.csp ?? CONSOLE_CSP,
        'cache-control': 'no-store, private',
      };
      if (rendered.cookies && rendered.cookies.length > 0) {
        siteHeaders['set-cookie'] = [...rendered.cookies];
      }
      if (rendered.redirect) {
        siteHeaders['location'] = rendered.redirect;
        response.writeHead(rendered.status, siteHeaders).end();
        return;
      }
      response.writeHead(rendered.status, siteHeaders);
      // HEAD gets the headers and no body, so a monitor can check a page
      // without rendering it.
      response.end(request.method === 'HEAD' ? undefined : (rendered.html ?? ''));
      return;
    }
  }

  // Static assets are served before the router. `serveStatic` only answers for
  // a file that actually exists with a content type we recognise, so an API
  // path always falls through to the router below.
  if (staticMounts.length > 0 && (await serveStatic(staticMounts, request, response, headers))) {
    return;
  }

  let rawBody = '';
  if (siteBody !== undefined) {
    // The body has already been consumed, above, before the site loop. A
    // request stream can only be read once: asking for it again waits on an
    // 'end' event that has already fired and will never fire twice, and the
    // request hangs until the client gives up.
    //
    // This is reachable whenever a site is mounted at '', because
    // `''.startsWith('')` is true of every path, so an API POST took the site
    // body-reading branch, was declined by the site, and then hung here. It
    // hung every POST the widget makes, which is every conversation.
    if ((siteBytes?.length ?? 0) > maxBodyBytes) {
      response.writeHead(413, headers).end(JSON.stringify({ error: 'SCHEMA_INVALID', message: 'Request body is too large.' }));
      return;
    }
    rawBody = siteBody;
  } else {
    try {
      rawBody = await readBody(request, maxBodyBytes);
    } catch {
      response.writeHead(413, headers).end(JSON.stringify({ error: 'SCHEMA_INVALID', message: 'Request body is too large.' }));
      return;
    }
  }

  let body: unknown;
  if (rawBody.length > 0) {
    try {
      body = JSON.parse(rawBody);
    } catch {
      response.writeHead(400, headers).end(JSON.stringify({ error: 'SCHEMA_INVALID', message: 'Body must be JSON.' }));
      return;
    }
  }

  const apiRequest: ApiRequest = {
    method: request.method ?? 'GET',
    path: new URL(request.url ?? '/', 'http://localhost').pathname,
    headers: request.headers as Record<string, string | undefined>,
    body,
    // The raw body is retained for webhook signature verification: a signature
    // is over the exact bytes sent, not over a re-serialised object.
    rawBody,
  };

  const result = await api.handle(apiRequest);
  response.writeHead(result.status, { ...headers, ...result.headers }).end(JSON.stringify(result.body));
}

/** Room for a document upload, above the API's much smaller cap. */
const MAX_UPLOAD_BYTES = 24 * 1024 * 1024;

function readBodyBytes(request: IncomingMessage, maxBytes: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks: Buffer[] = [];
    request.on('data', (chunk: Buffer) => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(new Error('body too large'));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => resolve(Buffer.concat(chunks)));
    request.on('error', reject);
  });
}

function readBody(request: IncomingMessage, maxBytes: number): Promise<string> {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks: Buffer[] = [];
    request.on('data', (chunk: Buffer) => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(new Error('body too large'));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    request.on('error', reject);
  });
}
