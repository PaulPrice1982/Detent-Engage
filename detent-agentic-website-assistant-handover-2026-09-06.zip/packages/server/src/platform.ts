import { systemClock, type Clock, type Jurisdiction, type TenantConfig } from '@detent/awa-core';
import { AuditLog, InMemoryAuditStore, type AuditStore } from '@detent/awa-audit';
import {
  ConsentService, InMemoryConsentStore, MeteringService, InMemoryUsageStore, PolicyEngine,
  type ConsentStore, type UsageStore,
} from '@detent/awa-policy';
import {
  ConnectorRegistry, CrmAdapter, InMemoryConnectionStore, InMemoryWriteReceiptStore,
  RateLimiter, WriteReceiptService, type ConnectionStore, type CrmConnector, type Credential,
  type WriteReceiptStore,
} from '@detent/awa-connectors';
import { IdentityResolutionService } from '@detent/awa-identity';
import { KnowledgeCorpus, RetrievalService, type KnowledgeArchive } from '@detent/awa-knowledge';
import {
  HandoffService, InMemoryCalendarService, InMemoryNotificationService, SessionManager,
  ToolExecutor, TurnOrchestrator, type ModelProvider, type Session,
} from '@detent/awa-agent';
import {
  GenerationService, StagingLedger, type Extractor, type PageFetcher,
} from '@detent/awa-onboarding';
import {
  PlaybookVersionStore, SimulationHarness, type ScenarioDriver,
} from '@detent/awa-studio';
import {
  InMemoryOutcomeStore, OutcomeService, type OutcomeDispatcher, type OutcomeStore,
} from '@detent/awa-outcomes';
import {
  ComplianceScorecardService, DataQualityScorecardService, FunnelService,
} from '@detent/awa-analytics';
import {
  FollowUpEngine, FrequencyLedger, InMemoryMessageSender, InMemorySuppressionStore, SuppressionList,
  type SuppressionStore,
} from '@detent/awa-followup';
import {
  AccountMatcher, EngagementRulesEngine, EnrichmentOrchestrator, SignalStore, VisitorSignalService,
  type CompanyResolver, type EnrichmentVendor,
} from '@detent/awa-signals';
import {
  CustomerContextService, SystemRegistry,
} from '@detent/awa-context';
import { EntitlementService, VerificationService, type CodeSender } from '@detent/awa-entitlement';
import { ModeSelector } from '@detent/awa-modes';
import { GroupIdentityService, HierarchyService, PartnerRegistry } from '@detent/awa-groups';
import { MachineSurface } from '@detent/awa-machine';
import { AssurancePackGenerator } from '@detent/awa-assurance';
import { TenantStore, type TenantArchive } from './tenant-store.js';

/**
 * Composition root.
 *
 * One place where every dependency is wired, so the trust boundaries are
 * visible in a single file rather than distributed across a framework's
 * container. The in-memory stores are the default; the Postgres adapters in
 * `db/` implement the same interfaces with row-level security enforced at the
 * database under a restricted role.
 */
export interface PlatformOptions {
  readonly model: ModelProvider;
  readonly clock?: Clock;
  readonly auditStore?: AuditStore;
  /**
   * Where knowledge and tenant configuration survive a restart.
   *
   * Both keep an in-memory index: they are read inside a conversation turn , 
   * and write through to the archive. Absent, they are memory only.
   */
  readonly knowledgeArchive?: KnowledgeArchive;
  readonly tenantArchive?: TenantArchive;
  readonly connectionStore?: ConnectionStore;
  /**
   * The stores that were memory only, and the reason each one is here.
   *
   * Every one of them lost its contents at every restart and disagreed between
   * two instances of the same deployment. Three were compliance exposure rather
   * than inconvenience: consent evidence, the suppression list, and the
   * metering the customer is billed from. Optional so a laptop and a test still
   * run entirely in memory; supplied in a deployment, where losing any of them
   * is a real event.
   */
  readonly consentStore?: ConsentStore;
  readonly usageStore?: UsageStore;
  readonly receiptStore?: WriteReceiptStore;
  readonly outcomeStore?: OutcomeStore;
  readonly suppressionStore?: SuppressionStore;
  readonly connectors?: readonly CrmConnector[];
  // --- v1.1 parity extension. Each is optional: a platform without a page
  // fetcher simply has no generation service, rather than a broken one.
  readonly pageFetcher?: PageFetcher;
  readonly extractor?: Extractor;
  readonly outcomeDispatcher?: OutcomeDispatcher;
  readonly companyResolver?: CompanyResolver;
  readonly enrichmentVendors?: readonly EnrichmentVendor[];
  readonly scenarioDriver?: ScenarioDriver;
  /** Base URL for opt-out links and outcome confirmation callbacks. */
  readonly publicBaseUrl?: string;
  /** Platform-wide salt for the global suppression digest. Never rotated. */
  readonly suppressionSalt?: string;
  // --- v1.2 unoccupied ground.
  readonly codeSender?: CodeSender;
}

export class Platform {
  readonly clock: Clock;
  readonly audit: AuditLog;
  readonly consent: ConsentService;
  readonly metering: MeteringService;
  readonly policy: PolicyEngine;
  readonly registry: ConnectorRegistry;
  readonly connections: ConnectionStore;
  readonly receipts: WriteReceiptService;
  readonly adapter: CrmAdapter;
  readonly identity: IdentityResolutionService;
  readonly corpus: KnowledgeCorpus;
  readonly retrieval: RetrievalService;
  readonly calendar: InMemoryCalendarService;
  readonly notifications: InMemoryNotificationService;
  readonly handoff: HandoffService;
  readonly sessions: SessionManager;
  readonly executor: ToolExecutor;
  readonly orchestrator: TurnOrchestrator;
  readonly tenants: TenantStore;

  // --- v1.1 parity extension
  readonly generation?: GenerationService;
  readonly staging: StagingLedger;
  readonly playbooks: PlaybookVersionStore;
  readonly simulation?: SimulationHarness;
  readonly outcomes: OutcomeService;
  readonly funnel: FunnelService;
  readonly dataQuality: DataQualityScorecardService;
  readonly compliance: ComplianceScorecardService;
  readonly followUp: FollowUpEngine;
  readonly suppression: SuppressionList;
  readonly messages: InMemoryMessageSender;
  readonly signals: VisitorSignalService;
  readonly signalStore: SignalStore;
  readonly engagement: EngagementRulesEngine;
  readonly enrichment?: EnrichmentOrchestrator;
  readonly accounts: AccountMatcher;

  // --- v1.2 unoccupied ground
  readonly systems: SystemRegistry;
  readonly customerContext: CustomerContextService;
  readonly verification: VerificationService;
  readonly entitlement: EntitlementService;
  readonly modes: ModeSelector;
  readonly hierarchy: HierarchyService;
  readonly groupIdentity: GroupIdentityService;
  readonly partners: PartnerRegistry;
  readonly machine: MachineSurface;
  readonly assurance: AssurancePackGenerator;

  /**
   * Platform-wide kill switch (section 13.6). Independent of the per-tenant
   * switch, and effective without a redeploy.
   */
  platformKillSwitch: 'OFF' | 'TEXT_ONLY' | 'BOOKING_LINK_ONLY' = 'OFF';

  constructor(options: PlatformOptions) {
    this.clock = options.clock ?? systemClock;
    this.audit = new AuditLog(options.auditStore ?? new InMemoryAuditStore(), this.clock);
    this.consent = new ConsentService(
      options.consentStore ?? new InMemoryConsentStore(), this.clock, this.audit,
    );
    this.metering = new MeteringService(
      options.usageStore ?? new InMemoryUsageStore(), undefined, this.clock,
    );
    this.policy = new PolicyEngine(this.consent, this.metering, this.audit);

    this.registry = new ConnectorRegistry();
    for (const connector of options.connectors ?? []) this.registry.register(connector);

    this.connections = options.connectionStore ?? new InMemoryConnectionStore();
    this.receipts = new WriteReceiptService(
      options.receiptStore ?? new InMemoryWriteReceiptStore(), this.clock,
    );
    this.adapter = new CrmAdapter(
      this.registry, this.connections, this.receipts, this.audit,
      new RateLimiter(this.clock), {}, this.clock,
    );

    this.identity = new IdentityResolutionService(this.consent, this.adapter, this.audit, this.clock);
    this.corpus = new KnowledgeCorpus(this.clock, options.knowledgeArchive);
    this.retrieval = new RetrievalService(this.corpus);
    this.calendar = new InMemoryCalendarService(this.clock);
    this.notifications = new InMemoryNotificationService(this.clock);
    this.handoff = new HandoffService(this.clock);
    this.sessions = new SessionManager(this.clock);

    // --- v1.1 parity extension, wired before the executor so the outcome
    // recorder can be handed to it.
    this.staging = new StagingLedger(this.clock);
    this.playbooks = new PlaybookVersionStore(this.audit, this.clock);
    this.outcomes = new OutcomeService(
      options.outcomeStore ?? new InMemoryOutcomeStore(),
      this.metering,
      this.audit,
      options.outcomeDispatcher ?? { async post() { return { status: 204 }; } },
      this.clock,
    );

    this.executor = new ToolExecutor({
      policy: this.policy, consent: this.consent, metering: this.metering, audit: this.audit,
      adapter: this.adapter, identity: this.identity, retrieval: this.retrieval,
      calendar: this.calendar, notifications: this.notifications, handoff: this.handoff,
      sessions: this.sessions, clock: this.clock,
      staging: this.staging,
      outcomes: {
        record: async (input) => {
          const recorded = await this.outcomes.record({
            config: input.config,
            conversationId: input.conversationId,
            correlationId: input.correlationId,
            outcome: input.outcome as never,
            person: input.person,
            qualification: input.qualification,
            callbackBaseUrl: options.publicBaseUrl,
          });
          return { outcome: recorded.outcome, billable: recorded.billable, state: recorded.state };
        },
      },
    });

    this.orchestrator = new TurnOrchestrator({
      model: options.model, executor: this.executor, sessions: this.sessions,
      audit: this.audit, metering: this.metering,
    });

    this.tenants = new TenantStore(this.audit, this.clock, options.tenantArchive);

    if (options.pageFetcher) {
      this.generation = new GenerationService(options.pageFetcher, this.audit, options.extractor, this.clock);
    }
    if (options.scenarioDriver) {
      this.simulation = new SimulationHarness(options.scenarioDriver, this.audit, this.clock);
    }

    this.funnel = new FunnelService(this.audit, this.metering, this.outcomes);
    this.dataQuality = new DataQualityScorecardService(this.audit, this.receipts);
    this.compliance = new ComplianceScorecardService(this.audit);

    const salt = options.suppressionSalt ?? 'awa-platform-suppression-salt';
    this.suppression = new SuppressionList(
      options.suppressionStore ?? new InMemorySuppressionStore(), salt, this.clock,
    );
    this.messages = new InMemoryMessageSender();
    this.followUp = new FollowUpEngine(
      this.messages,
      this.suppression,
      new FrequencyLedger(salt, this.clock),
      this.audit,
      options.publicBaseUrl ?? '',
      this.clock,
    );

    // Short-retention behavioural store: fifteen minutes is long enough for an
    // engagement decision and short enough that it is not a profile.
    this.signalStore = new SignalStore(900, this.clock);
    this.signals = new VisitorSignalService(this.signalStore, this.consent, this.audit, options.companyResolver);
    this.engagement = new EngagementRulesEngine(this.audit);
    this.accounts = new AccountMatcher(this.adapter);
    if (options.enrichmentVendors?.length) {
      this.enrichment = new EnrichmentOrchestrator(options.enrichmentVendors, this.metering, 8.0, 90, this.clock);
    }

    // --- v1.2: the systems beyond the CRM.
    this.systems = new SystemRegistry();
    this.customerContext = new CustomerContextService(
      (tenantId) => this.systems.forTenant(tenantId), this.audit, this.clock,
    );
    this.verification = new VerificationService(
      options.codeSender ?? { async send() { /* development default */ } },
      this.audit, this.clock,
    );
    this.entitlement = new EntitlementService(this.audit);
    this.modes = new ModeSelector(this.audit);
    this.hierarchy = new HierarchyService(this.audit, this.clock);
    this.groupIdentity = new GroupIdentityService(
      this.hierarchy, this.audit,
      // Per-group salt, so two groups never produce the same digest for a
      // person. Derived from the platform salt rather than stored per group.
      (groupId) => `${salt}:${groupId}`,
    );
    this.partners = new PartnerRegistry(this.audit);
    this.machine = new MachineSurface(this.audit, this.clock);
    this.assurance = new AssurancePackGenerator(this.audit, this.compliance);
  }

  async connectCrm(tenantId: string, connector: string, credential: Credential): Promise<void> {
    await this.connections.put({ tenantId, connector, credential, state: 'CONNECTED' });
  }

  /**
   * Effective kill switch for a tenant: the stricter of the platform-wide and
   * per-tenant settings. A platform incident cannot be overridden by a tenant.
   */
  effectiveConfig(tenantId: string): TenantConfig {
    const config = this.tenants.get(tenantId);
    const order = { OFF: 0, TEXT_ONLY: 1, BOOKING_LINK_ONLY: 2 } as const;
    const killSwitch = order[this.platformKillSwitch] >= order[config.killSwitch]
      ? this.platformKillSwitch
      : config.killSwitch;
    return killSwitch === config.killSwitch ? config : { ...config, killSwitch };
  }

  async openSession(tenantId: string, jurisdiction: Jurisdiction, modality: 'text' | 'voice' = 'text'): Promise<Session> {
    const config = this.effectiveConfig(tenantId);
    const session = this.sessions.open(config, jurisdiction, modality);
    await this.metering.record(tenantId, 'conversation', 1);
    await this.audit.write({
      tenantId, type: 'session_opened', correlationId: session.correlationId,
      sessionId: session.id, actor: 'system',
      payload: { modality, jurisdiction, state: config.state },
      versions: session.versions,
    });
    return session;
  }
}
