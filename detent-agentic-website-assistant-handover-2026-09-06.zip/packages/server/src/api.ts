import { AwaError, isAwaError, type Jurisdiction } from '@detent/awa-core';
import { allTime, type ReportWindow } from '@detent/awa-analytics';
import { evaluatePublishGate } from '@detent/awa-studio';
import { generateLiaTemplate } from '@detent/awa-followup';
import { ApiKeyService, type Principal } from './auth.js';
import { ChangeEventProcessor, parseChangeEvent } from './webhooks.js';
import type { Platform } from './platform.js';

/**
 * The public API surface, expressed as a transport-agnostic router.
 *
 * Keeping the handlers free of Node's http types means the same routes are
 * exercised by the test suite directly, by the demo, and by the HTTP server , 
 * so the cross-tenant probe suite tests the real authorisation path rather than
 * a mock of it.
 */
export interface ApiRequest {
  readonly method: string;
  readonly path: string;
  readonly headers: Readonly<Record<string, string | undefined>>;
  readonly body?: unknown;
  readonly rawBody?: string;
}

export interface ApiResponse {
  readonly status: number;
  readonly body: unknown;
  readonly headers?: Readonly<Record<string, string>>;
}

const json = (status: number, body: unknown, headers?: Record<string, string>): ApiResponse => ({ status, body, headers });

export class Api {
  constructor(
    private readonly platform: Platform,
    readonly keys: ApiKeyService = new ApiKeyService(),
    private readonly events: ChangeEventProcessor = new ChangeEventProcessor(platform.audit),
    private readonly webhookSecrets: Map<string, string> = new Map(),
  ) {}

  setWebhookSecret(connector: string, secret: string): void {
    this.webhookSecrets.set(connector, secret);
  }

  async handle(request: ApiRequest): Promise<ApiResponse> {
    try {
      return await this.route(request);
    } catch (cause) {
      if (isAwaError(cause)) {
        return json(statusFor(cause), {
          error: cause.kind,
          message: cause.visitorMessage,
          correlation_id: cause.correlationId,
        });
      }
      return json(500, { error: 'INTERNAL', message: 'Something went wrong at our end.' });
    }
  }

  private async route(request: ApiRequest): Promise<ApiResponse> {
    const segments = request.path.split('/').filter(Boolean);
    const [version, resource, ...rest] = segments;

    if (request.method === 'GET' && request.path === '/health') {
      return json(200, { status: 'ok', killSwitch: this.platform.platformKillSwitch });
    }

    if (version !== 'v1') return json(404, { error: 'NOT_FOUND', message: 'Unknown route.' });

    // Webhooks authenticate by signature, not by API key.
    if (resource === 'webhooks') return this.handleWebhook(request, rest[0]);

    const principal = this.keys.authenticate(bearerHeader(request.headers));

    switch (resource) {
      case 'sessions': return this.handleSessions(request, principal, rest);
      case 'admin': return this.handleAdmin(request, principal, rest);
      case 'outcomes': return this.handleOutcomes(request, principal, rest);
      default: return json(404, { error: 'NOT_FOUND', message: 'Unknown route.' });
    }
  }

  // --- visitor-facing -----------------------------------------------------

  private async handleSessions(request: ApiRequest, principal: Principal, rest: string[]): Promise<ApiResponse> {
    this.keys.assertAudience(principal, 'widget', 'tenant_admin');

    if (request.method === 'POST' && rest.length === 0) {
      const body = (request.body ?? {}) as { jurisdiction?: Jurisdiction; modality?: 'text' | 'voice'; consent?: Record<string, boolean> };
      const config = this.platform.effectiveConfig(principal.tenantId);
      const session = await this.platform.openSession(
        principal.tenantId,
        body.jurisdiction ?? config.homeJurisdiction,
        body.modality ?? 'text',
      );

      // The widget reads the host page's consent signal rather than setting its
      // own. A widget that sets identifiers regardless of the host's consent
      // state makes the platform complicit in the tenant's breach (table 35).
      if (body.consent?.['identity_resolution'] === true) {
        await this.platform.consent.record({
          tenantId: principal.tenantId,
          subjectRef: session.subjectRef,
          purpose: 'IDENTITY_RESOLUTION',
          choice: 'GRANTED',
          wordingShown: 'Host consent management platform reported an affirmative signal for personalisation.',
          source: 'HOST_CMP',
          jurisdiction: session.jurisdiction,
          correlationId: session.correlationId,
        });
      }

      return json(201, {
        session_id: session.id,
        // The disclosure is returned at session open so the widget can render
        // it before the first message, in the surface itself.
        disclosure: session.modality === 'voice' ? config.disclosure.voiceText : config.disclosure.text,
        modality: session.modality,
        text_only_route_available: true,
        kill_switch: config.killSwitch,
      });
    }

    const sessionId = rest[0];
    if (!sessionId) return json(404, { error: 'NOT_FOUND', message: 'Unknown route.' });
    const session = this.platform.sessions.get(sessionId);
    if (!session) return json(404, { error: 'NOT_FOUND', message: 'Unknown session.' });
    // Session ownership is checked against the key's tenant, not the payload.
    this.keys.assertTenantAccess(principal, session.tenantId);

    if (request.method === 'POST' && rest[1] === 'messages') {
      const body = (request.body ?? {}) as { text?: string };
      if (typeof body.text !== 'string' || body.text.trim().length === 0) {
        return json(400, { error: 'SCHEMA_INVALID', message: 'A message is required.' });
      }
      const result = await this.platform.orchestrator.run({
        session,
        config: this.platform.effectiveConfig(session.tenantId),
        visitorInput: body.text,
      });
      return json(200, {
        text: result.text,
        disclosure: result.disclosure,
        escalated: result.escalated,
        correlation_id: result.correlationId,
      });
    }

    if (request.method === 'POST' && rest[1] === 'consent') {
      const body = (request.body ?? {}) as { purpose?: string; granted?: boolean; wording?: string };
      if (!body.purpose || typeof body.granted !== 'boolean' || !body.wording) {
        return json(400, { error: 'SCHEMA_INVALID', message: 'purpose, granted and wording are required.' });
      }
      const event = await this.platform.consent.record({
        tenantId: session.tenantId,
        subjectRef: session.subjectRef,
        purpose: body.purpose as 'IDENTITY_RESOLUTION' | 'MARKETING' | 'RECORDING' | 'TRANSCRIPTION',
        choice: body.granted ? 'GRANTED' : 'REFUSED',
        // The exact wording shown, stored verbatim. This is the evidence.
        wordingShown: body.wording,
        source: 'WIDGET_PROMPT',
        jurisdiction: session.jurisdiction,
        correlationId: session.correlationId,
      });
      return json(201, { consent_event_id: event.id, choice: event.choice });
    }

    return json(404, { error: 'NOT_FOUND', message: 'Unknown route.' });
  }

  // --- tenant and platform administration ---------------------------------

  private async handleAdmin(request: ApiRequest, principal: Principal, rest: string[]): Promise<ApiResponse> {
    this.keys.assertAudience(principal, 'tenant_admin', 'platform_admin');
    const [collection, tenantId, action] = rest;

    if (collection === 'kill-switch' && request.method === 'POST') {
      this.keys.assertAudience(principal, 'platform_admin');
      const body = (request.body ?? {}) as { mode?: 'OFF' | 'TEXT_ONLY' | 'BOOKING_LINK_ONLY' };
      this.platform.platformKillSwitch = body.mode ?? 'OFF';
      await this.platform.audit.write({
        tenantId: '*platform*', type: 'kill_switch_engaged',
        correlationId: `kill_${Date.now()}`, actor: 'platform_admin',
        payload: { mode: this.platform.platformKillSwitch },
      });
      return json(200, { kill_switch: this.platform.platformKillSwitch });
    }

    if (collection !== 'tenants' || !tenantId) {
      return json(404, { error: 'NOT_FOUND', message: 'Unknown route.' });
    }
    this.keys.assertTenantAccess(principal, tenantId);

    if (request.method === 'GET' && !action) {
      return json(200, redactConfig(this.platform.tenants.get(tenantId)));
    }

    if (request.method === 'PATCH' && !action) {
      const updated = this.platform.tenants.update(tenantId, (request.body ?? {}) as never, principal.audience);
      return json(200, redactConfig(updated));
    }

    switch (action) {
      case 'audit': {
        // The exportable audit trail, with its own chain verification attached,
        // is what a tenant DPO asks for and what makes the governance claim
        // checkable rather than asserted.
        const exported = await this.platform.audit.export(tenantId);
        return json(200, { entries: exported.entries, verification: exported.verification });
      }
      case 'usage': {
        const usage = await this.platform.metering.usage(tenantId);
        const perConversation = await this.platform.metering.costPerConversationPence(tenantId);
        return json(200, { usage, cost_per_conversation_pence: perConversation });
      }
      case 'capabilities': {
        const capabilities = await this.platform.adapter.capabilities(tenantId);
        return json(200, capabilities);
      }
      case 'handoffs':
        return json(200, { handoffs: this.platform.handoff.forTenant(tenantId) });
      case 'reconcile': {
        const pending = await this.platform.receipts.pendingReconciliation(tenantId);
        return json(200, { pending: pending.length, receipts: pending });
      }
      case 'analytics': {
        const report = await this.platform.funnel.build(tenantId, this.window(request), this.platform.clock.iso());
        return json(200, report);
      }
      case 'data-quality': {
        const scorecard = await this.platform.dataQuality.build(
          tenantId, this.window(request), this.platform.clock.iso(), this.platform.clock.nowMs(),
        );
        return json(200, scorecard);
      }
      case 'compliance': {
        // The single highest-leverage surface in the extension: a compliance
        // architecture the buyer cannot see, turned into a report they can take
        // to their own board. Machine-readable, any date range, one action.
        const scorecard = await this.platform.compliance.build(tenantId, this.window(request), this.platform.clock.iso());
        return json(200, scorecard, { 'content-disposition': `attachment; filename="compliance-${tenantId}.json"` });
      }
      case 'generation': {
        if (request.method === 'POST') return this.startGeneration(request, tenantId);
        if (!this.platform.generation) return json(501, { error: 'NOT_FOUND', message: 'Generation is not configured.' });
        const result = this.platform.generation.get(tenantId);
        return json(200, { ...result, coverage: this.platform.generation.coverage(tenantId) });
      }
      case 'approve': {
        if (!this.platform.generation) return json(501, { error: 'NOT_FOUND', message: 'Generation is not configured.' });
        const body = (request.body ?? {}) as { section?: string; items?: string[]; approvedBy?: string; signOff?: boolean };
        if (!body.section || !body.approvedBy) {
          return json(400, { error: 'SCHEMA_INVALID', message: 'section and approvedBy are required.' });
        }
        const correlationId = `approve_${this.platform.clock.nowMs()}`;
        if (body.items?.length) {
          await this.platform.generation.approveItems(tenantId, body.section as never, body.items, body.approvedBy, correlationId);
        }
        if (body.signOff) {
          await this.platform.generation.approveSection(tenantId, body.section as never, body.approvedBy, correlationId);
        }
        return json(200, { coverage: this.platform.generation.coverage(tenantId), fullyApproved: this.platform.generation.fullyApproved(tenantId) });
      }
      case 'dry-run': {
        if (request.method === 'GET') return json(200, this.platform.staging.diff(tenantId));
        if (request.method === 'POST') {
          // Accepting the diff is what enables real CRM writes (FR-036).
          const applied = this.platform.staging.accept(tenantId);
          this.platform.tenants.update(tenantId, { dryRun: false }, principal.audience);
          return json(200, { applied: applied.length, dryRun: false });
        }
        return json(405, { error: 'SCHEMA_INVALID', message: 'Use GET to review or POST to accept.' });
      }
      case 'playbooks': {
        const versions = this.platform.playbooks.list(tenantId);
        return json(200, {
          versions: versions.map((version) => ({
            version: version.version, author: version.author, publishedAt: version.publishedAt,
            note: version.note, restoredFrom: version.restoredFrom, simulationRunId: version.simulationRunId,
          })),
          active: this.platform.playbooks.activeVersion(tenantId)?.version,
        });
      }
      case 'rollback': {
        const body = (request.body ?? {}) as { version?: number; author?: string };
        if (typeof body.version !== 'number' || !body.author) {
          return json(400, { error: 'SCHEMA_INVALID', message: 'version and author are required.' });
        }
        const restored = await this.platform.playbooks.restore(
          tenantId, body.version, body.author, `rollback_${this.platform.clock.nowMs()}`,
        );
        this.platform.tenants.update(tenantId, { playbookVersion: restored.version }, principal.audience);
        return json(200, { version: restored.version, restoredFrom: restored.restoredFrom });
      }
      case 'simulate': {
        if (!this.platform.simulation) return json(501, { error: 'NOT_FOUND', message: 'Simulation is not configured.' });
        const config = this.platform.effectiveConfig(tenantId);
        const scorecard = await this.platform.simulation.run(config, `simulate_${this.platform.clock.nowMs()}`);
        const gate = evaluatePublishGate(scorecard);
        // Blocked, not warned (FR-042).
        return json(gate.allowed ? 200 : 422, { scorecard, publishGate: gate });
      }
      case 'lia': {
        if (request.method === 'POST') {
          const body = (request.body ?? {}) as { completedBy?: string };
          if (!body.completedBy) return json(400, { error: 'SCHEMA_INVALID', message: 'completedBy is required.' });
          const current = this.platform.tenants.get(tenantId);
          const updated = this.platform.tenants.update(tenantId, {
            followUp: {
              ...current.followUp,
              liaComplete: true,
              liaCompletedAt: this.platform.clock.iso(),
              liaCompletedBy: body.completedBy,
            },
          }, principal.audience);
          return json(200, { liaComplete: updated.followUp.liaComplete, completedBy: body.completedBy });
        }
        return json(200, { template: generateLiaTemplate(this.platform.tenants.get(tenantId)) });
      }
      case 'lifecycle': {
        const body = (request.body ?? {}) as { to?: string };
        const updated = this.platform.tenants.transition(tenantId, body.to as never, principal.audience);
        return json(200, redactConfig(updated));
      }
      default:
        return json(404, { error: 'NOT_FOUND', message: 'Unknown route.' });
    }
  }

  /** Reporting window from query-free path params; defaults to all time. */
  private window(request: ApiRequest): ReportWindow {
    const body = (request.body ?? {}) as { from?: string; to?: string };
    if (body.from && body.to) return { from: body.from, to: body.to };
    return allTime();
  }

  private async startGeneration(request: ApiRequest, tenantId: string): Promise<ApiResponse> {
    if (!this.platform.generation) {
      return json(501, { error: 'NOT_FOUND', message: 'Generation is not configured on this deployment.' });
    }
    const body = (request.body ?? {}) as { rootUrl?: string; seedUrls?: string[] };
    if (!body.rootUrl) return json(400, { error: 'SCHEMA_INVALID', message: 'rootUrl is required.' });

    const config = this.platform.tenants.get(tenantId);
    const capabilities = await this.platform.adapter.capabilities(tenantId);
    const owners = await this.platform.adapter.readOwners(tenantId);
    const pipelines = await this.platform.adapter.readPipelines(tenantId);

    const result = await this.platform.generation.generate({
      tenantId,
      rootUrl: body.rootUrl,
      correlationId: `generate_${this.platform.clock.nowMs()}`,
      crawl: { seedUrls: body.seedUrls },
      qualification: config.qualification,
      objections: config.objections,
      // Schema introspection would come from the connector; where a connector
      // does not expose one, the mapping generator returns what it can and the
      // uncovered fields are named rather than silently dropped.
      crmSchemas: [],
      owners,
      pipelines,
      capabilities,
    });

    return json(201, {
      durationMs: result.durationMs,
      knowledge: { items: result.knowledge.items.length, pagesCrawled: result.knowledge.pagesCrawled },
      playbook: {
        approvalState: result.playbook.approvalState,
        services: result.playbook.serviceCatalogue.length,
        prices: result.playbook.priceList.length,
        claims: result.playbook.approvedClaims.length,
      },
      mapping: { standardFieldCoverage: result.mapping.standardFieldCoverage, unmapped: result.mapping.unmapped },
      routing: { rules: result.routing.rules.length, ownerCount: result.routing.ownerCount },
      // Stated back explicitly so nobody can claim they thought it was live.
      nothingServesUntilApproved: true,
    });
  }

  /** Outcome confirmation callback (FR-046). Authenticated by signature. */
  private async handleOutcomes(request: ApiRequest, principal: Principal, rest: string[]): Promise<ApiResponse> {
    const [correlationId, action] = rest;
    if (!correlationId || action !== 'confirm' || request.method !== 'POST') {
      return json(404, { error: 'NOT_FOUND', message: 'Unknown route.' });
    }
    const body = (request.body ?? {}) as { succeeded?: boolean; reason?: string };
    const confirmed = await this.platform.outcomes.confirm(principal.tenantId, correlationId, {
      succeeded: body.succeeded !== false,
      reason: body.reason,
    });
    return json(200, { outcome: confirmed.outcome, state: confirmed.state, billable: confirmed.billable });
  }

  // --- inbound CRM change events ------------------------------------------

  private async handleWebhook(request: ApiRequest, connector: string | undefined): Promise<ApiResponse> {
    if (!connector || request.method !== 'POST') {
      return json(404, { error: 'NOT_FOUND', message: 'Unknown route.' });
    }
    const secret = this.webhookSecrets.get(connector);
    const signature = request.headers['x-signature'] ?? '';
    const verified = Boolean(secret) && this.events.verifySignature(secret!, request.rawBody ?? '', signature);

    const event = parseChangeEvent(request.body);
    const outcome = await this.events.process(event, { signatureVerified: verified });
    return json(outcome === 'rejected_signature' ? 401 : 202, { outcome });
  }
}

function bearerHeader(headers: Readonly<Record<string, string | undefined>>): string | undefined {
  const header = headers['authorization'] ?? headers['Authorization'];
  return header?.startsWith('Bearer ') ? header.slice(7) : undefined;
}

function statusFor(error: AwaError): number {
  switch (error.kind) {
    case 'POLICY_DENIED': return 403;
    case 'CONSENT_REQUIRED': return 403;
    case 'SCHEMA_INVALID': return 400;
    case 'TENANT_NOT_FOUND':
    case 'NOT_FOUND': return 404;
    case 'CONFLICT': return 409;
    case 'RATE_LIMITED': return 429;
    case 'QUOTA_EXCEEDED':
    case 'SPEND_CAP_REACHED': return 402;
    case 'UPSTREAM_UNAVAILABLE':
    case 'CONNECTION_DEGRADED': return 503;
    default: return 500;
  }
}

/** Configuration is returned without anything that is not the tenant's to see. */
function redactConfig(config: ReturnType<Platform['tenants']['get']>): Record<string, unknown> {
  return {
    tenant_id: config.tenantId,
    name: config.name,
    version: config.version,
    state: config.state,
    residency: config.residency,
    connector: config.connector,
    kill_switch: config.killSwitch,
    disclosure: config.disclosure,
    service_catalogue: config.serviceCatalogue,
    price_list: config.priceList,
    qualification: config.qualification,
    escalation: config.escalation,
    spend_caps: config.spendCaps,
    retention: config.retention,
    recording: config.recording,
    versions: {
      prompt: config.promptVersion,
      policy: config.policyVersion,
      model: config.modelVersion,
    },
    dpa_signed_at: config.dpaSignedAt,
    field_mapping_accepted_at: config.fieldMappingAcceptedAt,
  };
}
