import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { AwaError } from '@detent/awa-core';

/**
 * Tenant-scoped API keys.
 *
 * Tenant binding is applied at the authorisation layer rather than the query
 * layer (table 34, elevation of privilege). A caller does not supply a tenant
 * id and have it checked; the tenant id is derived from the key, so a request
 * naming another tenant cannot be authorised at all.
 *
 * Keys are stored as SHA-256 digests. A stolen database gives an attacker
 * hashes, not keys.
 */
export type Audience = 'widget' | 'tenant_admin' | 'platform_admin';

export interface ApiKeyRecord {
  readonly id: string;
  readonly tenantId: string;
  readonly audience: Audience;
  readonly digest: string;
  readonly createdAt: string;
  revokedAt?: string;
}

export interface Principal {
  readonly tenantId: string;
  readonly audience: Audience;
  readonly keyId: string;
}

export class ApiKeyService {
  private readonly keys = new Map<string, ApiKeyRecord>();

  issue(tenantId: string, audience: Audience): { key: string; record: ApiKeyRecord } {
    const secret = randomBytes(24).toString('base64url');
    const key = `awa_${audience === 'widget' ? 'pub' : 'sk'}_${tenantId}_${secret}`;
    const record: ApiKeyRecord = {
      id: `ak_${randomBytes(8).toString('hex')}`,
      tenantId,
      audience,
      digest: digestOf(key),
      createdAt: new Date().toISOString(),
    };
    this.keys.set(record.digest, record);
    return { key, record };
  }

  revoke(keyId: string): void {
    for (const record of this.keys.values()) {
      if (record.id === keyId) record.revokedAt = new Date().toISOString();
    }
  }

  authenticate(presented: string | undefined): Principal {
    if (!presented) {
      throw new AwaError({ kind: 'POLICY_DENIED', message: 'no API key presented' });
    }
    const record = this.keys.get(digestOf(presented));
    if (!record || record.revokedAt) {
      throw new AwaError({ kind: 'POLICY_DENIED', message: 'API key is not recognised' });
    }
    // Constant-time confirmation on the digest as well, so a partial-match
    // oracle cannot be built from response timing on the map lookup.
    const a = Buffer.from(record.digest, 'hex');
    const b = Buffer.from(digestOf(presented), 'hex');
    if (a.length !== b.length || !timingSafeEqual(a, b)) {
      throw new AwaError({ kind: 'POLICY_DENIED', message: 'API key is not recognised' });
    }
    return { tenantId: record.tenantId, audience: record.audience, keyId: record.id };
  }

  /**
   * The cross-tenant guard. Every handler that takes a tenant id in the path
   * calls this. A platform admin is the only principal permitted to address a
   * tenant other than its own, and that access is audited by the caller.
   */
  assertTenantAccess(principal: Principal, tenantId: string): void {
    if (principal.audience === 'platform_admin') return;
    if (principal.tenantId !== tenantId) {
      throw new AwaError({
        kind: 'POLICY_DENIED',
        message: 'cross-tenant access denied',
        details: { presentedTenant: principal.tenantId, requestedTenant: tenantId },
      });
    }
  }

  assertAudience(principal: Principal, ...allowed: Audience[]): void {
    if (!allowed.includes(principal.audience)) {
      throw new AwaError({
        kind: 'POLICY_DENIED',
        message: `audience ${principal.audience} may not perform this operation`,
      });
    }
  }
}

function digestOf(key: string): string {
  return createHash('sha256').update(key).digest('hex');
}
