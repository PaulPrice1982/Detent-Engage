import { AwaError, type Clock, type SpendCaps, systemClock } from '@detent/awa-core';

/**
 * Per-tenant metering, quota and spend-cap enforcement (FR-026, section 32.5).
 *
 * Denial of wallet is the acute multi-tenant risk: a bot flood on one tenant's
 * site burns pooled voice minutes at burst pricing. The cap is therefore
 * enforced here, before the spend is incurred, rather than reconciled at
 * invoicing. Approaching the cap degrades to text; reaching it stops spend.
 */
export type MeterKind =
  | 'conversation' | 'text_message' | 'voice_minute' | 'crm_call' | 'llm_token'
  /** A confirmed billable outcome (section 40). Revenue, not cost. */
  | 'qualified_outcome'
  /** A per-record third-party enrichment cost (section 43.4). */
  | 'enrichment_record'
  | 'company_resolution';

export interface UsageRecord {
  readonly tenantId: string;
  readonly period: string; // YYYY-MM
  conversations: number;
  textMessages: number;
  voiceMinutes: number;
  crmCalls: number;
  llmTokens: number;
  /** Confirmed billable outcomes. Counted, never a cost. */
  qualifiedOutcomes: number;
  enrichmentRecords: number;
  companyResolutions: number;
  /** Accrued cost of goods in pence, so the cap is enforced in money, not units. */
  spendPence: number;
  concurrentVoice: number;
}

/**
 * Blended unit costs in pence (section 32.1, at £1 = $1.27). These are cost of
 * goods, not price. They are configuration, not constants, precisely because
 * every one of them is a vendor figure that moves.
 */
export interface UnitCostsPence {
  readonly voiceMinute: number;
  readonly voiceMinuteBurst: number;
  readonly textMessage: number;
  readonly llmPerThousandTokens: number;
  readonly crmCall: number;
  readonly conversationOverhead: number;
  /**
   * Enrichment is the first component with a per-record marginal cost paid to a
   * third party (section 43.4), and it changes the unit economics materially.
   * It is metered as credits and the cost is shown before a bulk routine runs.
   */
  readonly enrichmentRecord: number;
  readonly companyResolution: number;
}

export const DEFAULT_UNIT_COSTS: UnitCostsPence = {
  voiceMinute: 6.3,        // $0.08 at 1.27
  voiceMinuteBurst: 12.6,  // $0.16 burst above the concurrency limit
  textMessage: 0.24,       // $0.003
  llmPerThousandTokens: 0.4,
  crmCall: 0.01,
  conversationOverhead: 2.0, // infrastructure, vector storage, observability
  enrichmentRecord: 8.0,     // vendor per-record cost, cached per tenant
  companyResolution: 1.5,    // reverse-IP company resolution, cached monthly
};

export type MeterVerdict =
  | { readonly state: 'OK' }
  | { readonly state: 'WARN'; readonly fractionUsed: number }
  | { readonly state: 'DEGRADE_TO_TEXT'; readonly fractionUsed: number }
  | { readonly state: 'BLOCKED'; readonly reason: 'spend_cap' | 'conversation_quota' | 'voice_concurrency' };

export interface UsageStore {
  get(tenantId: string, period: string): Promise<UsageRecord | undefined>;
  put(record: UsageRecord): Promise<void>;
}

export class InMemoryUsageStore implements UsageStore {
  private readonly records = new Map<string, UsageRecord>();
  private key(tenantId: string, period: string): string { return `${tenantId}:${period}`; }
  async get(tenantId: string, period: string): Promise<UsageRecord | undefined> {
    return this.records.get(this.key(tenantId, period));
  }
  async put(record: UsageRecord): Promise<void> {
    this.records.set(this.key(record.tenantId, record.period), record);
  }
}

function emptyRecord(tenantId: string, period: string): UsageRecord {
  return {
    tenantId, period,
    conversations: 0, textMessages: 0, voiceMinutes: 0, crmCalls: 0, llmTokens: 0,
    qualifiedOutcomes: 0, enrichmentRecords: 0, companyResolutions: 0,
    spendPence: 0, concurrentVoice: 0,
  };
}

export class MeteringService {
  constructor(
    private readonly store: UsageStore,
    private readonly costs: UnitCostsPence = DEFAULT_UNIT_COSTS,
    private readonly clock: Clock = systemClock,
  ) {}

  private period(): string {
    return this.clock.iso().slice(0, 7);
  }

  async usage(tenantId: string): Promise<UsageRecord> {
    const period = this.period();
    return (await this.store.get(tenantId, period)) ?? emptyRecord(tenantId, period);
  }

  /**
   * Check before spending. Called at session open and before any voice session
   * or bulk routine, so a tenant is never silently overspent on.
   */
  async check(tenantId: string, caps: SpendCaps, intent: { voice?: boolean } = {}): Promise<MeterVerdict> {
    const usage = await this.usage(tenantId);

    if (usage.spendPence >= caps.monthlyPence) {
      return { state: 'BLOCKED', reason: 'spend_cap' };
    }
    if (usage.conversations >= caps.maxConversationsPerMonth) {
      return { state: 'BLOCKED', reason: 'conversation_quota' };
    }
    if (intent.voice && usage.concurrentVoice >= caps.maxConcurrentVoice) {
      return { state: 'BLOCKED', reason: 'voice_concurrency' };
    }

    const fractionUsed = usage.spendPence / caps.monthlyPence;
    if (fractionUsed >= caps.degradeToTextAtFraction) {
      return { state: 'DEGRADE_TO_TEXT', fractionUsed };
    }
    if (fractionUsed >= caps.warnAtFraction) {
      return { state: 'WARN', fractionUsed };
    }
    return { state: 'OK' };
  }

  async record(tenantId: string, kind: MeterKind, quantity: number, options: { burst?: boolean } = {}): Promise<UsageRecord> {
    const usage = { ...(await this.usage(tenantId)) };
    switch (kind) {
      case 'conversation':
        usage.conversations += quantity;
        usage.spendPence += quantity * this.costs.conversationOverhead;
        break;
      case 'text_message':
        usage.textMessages += quantity;
        usage.spendPence += quantity * this.costs.textMessage;
        break;
      case 'voice_minute':
        usage.voiceMinutes += quantity;
        usage.spendPence += quantity * (options.burst ? this.costs.voiceMinuteBurst : this.costs.voiceMinute);
        break;
      case 'crm_call':
        usage.crmCalls += quantity;
        usage.spendPence += quantity * this.costs.crmCall;
        break;
      case 'llm_token':
        usage.llmTokens += quantity;
        usage.spendPence += (quantity / 1000) * this.costs.llmPerThousandTokens;
        break;
      case 'qualified_outcome':
        // Counted, never costed. A confirmed outcome is what the tenant pays
        // for, so adding it to spendPence would double-count it as a cost.
        usage.qualifiedOutcomes += quantity;
        break;
      case 'enrichment_record':
        usage.enrichmentRecords += quantity;
        usage.spendPence += quantity * this.costs.enrichmentRecord;
        break;
      case 'company_resolution':
        usage.companyResolutions += quantity;
        usage.spendPence += quantity * this.costs.companyResolution;
        break;
    }
    usage.spendPence = Math.round(usage.spendPence * 1000) / 1000;
    await this.store.put(usage);
    return usage;
  }

  async openVoiceSession(tenantId: string, caps: SpendCaps): Promise<void> {
    const usage = { ...(await this.usage(tenantId)) };
    if (usage.concurrentVoice >= caps.maxConcurrentVoice) {
      throw new AwaError({
        kind: 'QUOTA_EXCEEDED',
        message: `voice concurrency cap of ${caps.maxConcurrentVoice} reached`,
        tenantId,
      });
    }
    usage.concurrentVoice += 1;
    await this.store.put(usage);
  }

  async closeVoiceSession(tenantId: string): Promise<void> {
    const usage = { ...(await this.usage(tenantId)) };
    usage.concurrentVoice = Math.max(0, usage.concurrentVoice - 1);
    await this.store.put(usage);
  }

  /** Blended cost of goods per conversation, tracked against the £0.60 target (NFR-015). */
  async costPerConversationPence(tenantId: string): Promise<number | undefined> {
    const usage = await this.usage(tenantId);
    if (usage.conversations === 0) return undefined;
    return usage.spendPence / usage.conversations;
  }
}
