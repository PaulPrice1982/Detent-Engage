import { createHash } from 'node:crypto';
import { newId, redactObject, type Clock, systemClock } from '@detent/awa-core';
import { canonicalJson } from './canonicalise.js';
import type { AuditEntry, AuditEntryInput, ChainVerification } from './types.js';

/**
 * Append-only, hash-chained audit log (section 29).
 *
 * The chain is per tenant. That is a deliberate isolation choice: a
 * platform-wide chain would let one tenant's export reveal the existence and
 * ordering of another tenant's activity, and would make a per-tenant erasure
 * or export request an operation on shared state.
 */
export const GENESIS_HASH = '0'.repeat(64);

export interface AuditStore {
  append(entry: AuditEntry): Promise<void>;
  lastEntry(tenantId: string): Promise<AuditEntry | undefined>;
  list(tenantId: string, options?: { limit?: number; sinceSequence?: number }): Promise<AuditEntry[]>;
  findByCorrelation(tenantId: string, correlationId: string): Promise<AuditEntry[]>;
}

export class InMemoryAuditStore implements AuditStore {
  private readonly byTenant = new Map<string, AuditEntry[]>();

  async append(entry: AuditEntry): Promise<void> {
    const list = this.byTenant.get(entry.tenantId) ?? [];
    list.push(entry);
    this.byTenant.set(entry.tenantId, list);
  }

  async lastEntry(tenantId: string): Promise<AuditEntry | undefined> {
    const list = this.byTenant.get(tenantId);
    return list?.[list.length - 1];
  }

  async list(tenantId: string, options: { limit?: number; sinceSequence?: number } = {}): Promise<AuditEntry[]> {
    const all = this.byTenant.get(tenantId) ?? [];
    const filtered = options.sinceSequence === undefined
      ? all
      : all.filter((e) => e.sequence > options.sinceSequence!);
    return options.limit ? filtered.slice(0, options.limit) : [...filtered];
  }

  async findByCorrelation(tenantId: string, correlationId: string): Promise<AuditEntry[]> {
    return (this.byTenant.get(tenantId) ?? []).filter((e) => e.correlationId === correlationId);
  }
}

export function hashEntry(entry: Omit<AuditEntry, 'hash'>): string {
  // The hash covers the previous hash and every field of the entry, so
  // reordering, editing or deleting an entry breaks every entry after it.
  return createHash('sha256').update(canonicalJson(entry)).digest('hex');
}

export class AuditLog {
  private readonly writeQueues = new Map<string, Promise<unknown>>();

  constructor(
    private readonly store: AuditStore,
    private readonly clock: Clock = systemClock,
  ) {}

  /**
   * Append an entry. Writes for a single tenant are serialised through a
   * per-tenant promise chain: two concurrent appends reading the same
   * `previousHash` would fork the chain and both would verify individually
   * while the log as a whole became unreconstructable.
   */
  async write(input: AuditEntryInput): Promise<AuditEntry> {
    const previous = this.writeQueues.get(input.tenantId) ?? Promise.resolve();
    const next = previous.then(() => this.appendSerialised(input));
    // Swallow rejection on the queue itself so one failed append does not
    // poison every later append for that tenant.
    this.writeQueues.set(input.tenantId, next.catch(() => undefined));
    return next;
  }

  private async appendSerialised(input: AuditEntryInput): Promise<AuditEntry> {
    const last = await this.store.lastEntry(input.tenantId);
    const unhashed: Omit<AuditEntry, 'hash'> = {
      ...input,
      payload: input.payload ? (redactObject(input.payload) as Record<string, unknown>) : undefined,
      id: newId('aud', this.clock.nowMs()),
      sequence: (last?.sequence ?? 0) + 1,
      recordedAt: this.clock.iso(),
      previousHash: last?.hash ?? GENESIS_HASH,
    };
    const entry: AuditEntry = { ...unhashed, hash: hashEntry(unhashed) };
    await this.store.append(entry);
    return entry;
  }

  /** Verify the chain end to end. Used in CI and by the tenant-facing export. */
  async verify(tenantId: string): Promise<ChainVerification> {
    const entries = await this.store.list(tenantId);
    let expectedPrevious = GENESIS_HASH;
    for (const [index, entry] of entries.entries()) {
      if (entry.sequence !== index + 1) {
        return { valid: false, checked: index, brokenAtSequence: entry.sequence, reason: 'sequence gap or reorder' };
      }
      if (entry.previousHash !== expectedPrevious) {
        return { valid: false, checked: index, brokenAtSequence: entry.sequence, reason: 'previous hash mismatch' };
      }
      const { hash, ...rest } = entry;
      if (hashEntry(rest) !== hash) {
        return { valid: false, checked: index, brokenAtSequence: entry.sequence, reason: 'entry content altered' };
      }
      expectedPrevious = hash;
    }
    return { valid: true, checked: entries.length };
  }

  /**
   * Reconstruct everything the platform did under one correlation id. This is
   * the replayability that makes the governance claim in section 33.4
   * demonstrable to a buyer rather than merely asserted.
   */
  async replay(tenantId: string, correlationId: string): Promise<AuditEntry[]> {
    const entries = await this.store.findByCorrelation(tenantId, correlationId);
    return entries.sort((a, b) => a.sequence - b.sequence);
  }

  async export(tenantId: string): Promise<{ entries: AuditEntry[]; verification: ChainVerification }> {
    return { entries: await this.store.list(tenantId), verification: await this.verify(tenantId) };
  }
}
