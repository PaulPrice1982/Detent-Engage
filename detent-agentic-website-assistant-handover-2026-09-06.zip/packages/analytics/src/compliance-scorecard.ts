import type { AuditLog } from '@detent/awa-audit';
import { payloadOf, payloadString, within, type ReportWindow } from './window.js';

/**
 * The compliance scorecard (section 41.3, FR-051).
 *
 * The extension's own verdict: this is the single highest-leverage item in the
 * programme. It takes a compliance architecture the buyer cannot see and turns
 * it into a report the buyer can take to their own board. It is also the
 * surface most likely to survive competitive copying, **because a competitor
 * cannot report on gates it does not have.**
 *
 * Every figure here is derived from the hash-chained audit log rather than from
 * a separate counter. That matters: a counter can drift or be reset, whereas a
 * number derived from a chain that verifies is a number the tenant can defend.
 * The export therefore carries the chain verification alongside the figures.
 */
export interface ConsentBreakdown {
  readonly purpose: string;
  readonly jurisdiction: string;
  readonly granted: number;
  readonly refused: number;
  readonly withdrawn: number;
}

export interface ComplianceScorecard {
  readonly tenantId: string;
  readonly window: ReportWindow;
  readonly generatedAt: string;

  /** Consent events captured, by purpose, jurisdiction and outcome. */
  readonly consentEvents: readonly ConsentBreakdown[];

  /** Demonstrates the PECR gate is operating, not merely specified. */
  readonly identityResolutionsBlockedForConsent: number;
  readonly identityResolutionsPerformed: number;

  /** Demonstrates the structural enforcement in section 25.3. */
  readonly marketingEnrolmentsBlocked: number;

  /** Every occasion the assistant declined to reveal CRM data. */
  readonly crmDisclosureDenials: number;

  /** Article 50. Target 100%. */
  readonly sessionsOpened: number;
  readonly sessionsWithDisclosure: number;
  readonly aiDisclosureCoveragePct: number;

  readonly recordingConsent: {
    readonly granted: number;
    readonly refused: number;
    readonly notOffered: number;
  };

  readonly erasureRequests: { readonly received: number; readonly completed: number };

  /** Security posture, made visible to the buyer. */
  readonly injectionAttemptsRefused: number;
  readonly crossTenantDenials: number;
  readonly outputsBlocked: number;

  /** Risk 14: a tenant who approved without reading is visible, not invisible. */
  readonly generatedContentApprovalCoveragePct: number | undefined;

  /** The chain the figures were derived from, and whether it verifies. */
  readonly evidence: {
    readonly auditEntriesExamined: number;
    readonly chainVerified: boolean;
    readonly brokenAtSequence?: number;
  };
}

export class ComplianceScorecardService {
  constructor(private readonly audit: AuditLog) {}

  async build(tenantId: string, window: ReportWindow, generatedAt: string): Promise<ComplianceScorecard> {
    const exported = await this.audit.export(tenantId);
    const entries = exported.entries.filter((entry) => within(entry, window));

    const count = (type: string): number => entries.filter((entry) => entry.type === type).length;

    // Consent, grouped by purpose and jurisdiction.
    const consentMap = new Map<string, ConsentBreakdown>();
    for (const entry of entries) {
      if (entry.type !== 'consent_recorded' && entry.type !== 'consent_withdrawn') continue;
      const payload = payloadOf(entry);
      const purpose = payloadString(entry, 'purpose') ?? 'UNKNOWN';
      const jurisdiction = payloadString(entry, 'jurisdiction') ?? 'UNKNOWN';
      const key = `${purpose}:${jurisdiction}`;
      const existing = consentMap.get(key) ?? { purpose, jurisdiction, granted: 0, refused: 0, withdrawn: 0 };
      const choice = String(payload['choice'] ?? '');
      consentMap.set(key, {
        ...existing,
        granted: existing.granted + (choice === 'GRANTED' ? 1 : 0),
        refused: existing.refused + (choice === 'REFUSED' ? 1 : 0),
        withdrawn: existing.withdrawn + (choice === 'WITHDRAWN' ? 1 : 0),
      });
    }

    const sessionsOpened = count('session_opened');
    const sessionsWithDisclosure = count('disclosure_shown');

    // Approval coverage across generated configuration, where any exists.
    const approvalEntries = entries.filter(
      (entry) => payloadString(entry, 'change') === 'generated_section_approved',
    );
    const coverages = approvalEntries
      .map((entry) => payloadOf(entry)['approvalCoverage'])
      .filter((value): value is number => typeof value === 'number');

    return {
      tenantId,
      window,
      generatedAt,
      consentEvents: [...consentMap.values()].sort((a, b) => a.purpose.localeCompare(b.purpose)),
      identityResolutionsBlockedForConsent: count('resolution_blocked_no_consent'),
      identityResolutionsPerformed: count('resolution_complete'),
      marketingEnrolmentsBlocked: count('enrolment_blocked_no_consent'),
      crmDisclosureDenials: entries.filter(
        (entry) =>
          entry.type === 'output_blocked' &&
          JSON.stringify(payloadOf(entry)['violations'] ?? []).includes('crm_disclosure'),
      ).length,
      sessionsOpened,
      sessionsWithDisclosure,
      aiDisclosureCoveragePct: sessionsOpened === 0 ? 100 : round((sessionsWithDisclosure / sessionsOpened) * 100),
      recordingConsent: {
        granted: countConsent(entries, 'RECORDING', 'GRANTED'),
        refused: countConsent(entries, 'RECORDING', 'REFUSED'),
        notOffered: count('recording_blocked_no_consent'),
      },
      erasureRequests: {
        received: count('consent_withdrawn'),
        completed: count('erasure_executed'),
      },
      injectionAttemptsRefused: count('injection_detected'),
      crossTenantDenials: count('cross_tenant_denied'),
      outputsBlocked: count('output_blocked'),
      generatedContentApprovalCoveragePct:
        coverages.length === 0 ? undefined : round((coverages.reduce((a, b) => a + b, 0) / coverages.length) * 100),
      evidence: {
        auditEntriesExamined: entries.length,
        chainVerified: exported.verification.valid,
        brokenAtSequence: exported.verification.brokenAtSequence,
      },
    };
  }

  /**
   * Machine-readable export over any date range, in one action (FR-051).
   *
   * The chain verification travels with the figures deliberately. A scorecard
   * whose underlying log does not verify is not evidence, and shipping it
   * without saying so would be the worst kind of compliance theatre.
   */
  async export(tenantId: string, window: ReportWindow, generatedAt: string): Promise<string> {
    const scorecard = await this.build(tenantId, window, generatedAt);
    return JSON.stringify(scorecard, null, 2);
  }
}

function countConsent(
  entries: readonly { type: string; payload?: Readonly<Record<string, unknown>> }[],
  purpose: string,
  choice: string,
): number {
  return entries.filter((entry) => {
    if (entry.type !== 'consent_recorded') return false;
    const payload = (entry.payload ?? {}) as Record<string, unknown>;
    return payload['purpose'] === purpose && payload['choice'] === choice;
  }).length;
}

const round = (value: number): number => Math.round(value * 10) / 10;
