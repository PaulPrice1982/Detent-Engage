import { AwaError, isAwaError, type TenantConfig } from '@detent/awa-core';
import type { AuditLog } from '@detent/awa-audit';
import { approvedFigures, evaluateEscalation, type MeteringService } from '@detent/awa-policy';
import { detectInjection } from '@detent/awa-knowledge';
import { buildSystemPrompt, type ModelProvider, type ModelTurnOutput, type ProposedToolCall } from './model.js';
import { buildToolCatalogue, type ToolDefinition } from './tools.js';
import { BLOCKED_OUTPUT_REPLACEMENT, validateOutput } from './output-validation.js';
import type { Session, SessionManager } from './session.js';
import type { ToolExecutor } from './tool-executor.js';

/**
 * The turn orchestrator.
 *
 * Implements the execution pipeline from section 13.1 exactly, in order, with
 * no fast path:
 *
 *   1 ingest → 2 retrieve → 3 reason → 4 validate → 5 policy → 6 authorise
 *   → 7 execute → 8 audit → 9 validate output → 10 emit
 *
 * Steps 4 to 8 live in the ToolExecutor because they run per tool call; this
 * class owns the turn as a whole, including the two things that must happen
 * whatever the model does: the Article 50 disclosure on the first turn, and
 * output validation before anything reaches the visitor.
 */
export interface TurnInput {
  readonly session: Session;
  readonly config: TenantConfig;
  readonly visitorInput: string;
}

export interface TurnResult {
  readonly text: string;
  readonly disclosure?: string;
  readonly toolsExecuted: readonly string[];
  readonly toolsDenied: readonly { tool: string; reason: string }[];
  readonly escalated: boolean;
  readonly outputViolations: readonly string[];
  readonly injectionDetected: boolean;
  readonly correlationId: string;
}

export interface OrchestratorDeps {
  readonly model: ModelProvider;
  readonly executor: ToolExecutor;
  readonly sessions: SessionManager;
  readonly audit: AuditLog;
  readonly metering: MeteringService;
}

const HUMAN_REQUEST = /\b(speak|talk|put me through|connect me|get me)\s+(to|with)?\s*(a|an|someone|somebody)?\s*(human|person|real person|agent|advisor|adviser|consultant|sales ?rep|someone)\b|\bhuman please\b/i;

export class TurnOrchestrator {
  constructor(private readonly deps: OrchestratorDeps) {}

  async run(input: TurnInput): Promise<TurnResult> {
    const { session, config } = input;
    const catalogue = buildToolCatalogue(config.serviceCatalogue);

    // --- Step 1: ingest. Visitor input is untrusted from here to the end.
    this.deps.sessions.record(session, 'visitor', input.visitorInput);
    if (session.state === 'Anonymous') this.deps.sessions.transition(session, 'Engaged');

    const injection = detectInjection(input.visitorInput);
    if (injection.detected) {
      // An injection attempt is a security event, not a conversation topic. It
      // is logged and refused; it is never argued with.
      await this.deps.audit.write({
        tenantId: session.tenantId, type: 'injection_detected',
        correlationId: session.correlationId, sessionId: session.id, actor: 'visitor',
        payload: { matches: injection.matches },
      });
    }

    if (HUMAN_REQUEST.test(input.visitorInput)) session.humanRequested = true;

    // --- The Article 50 disclosure. Shown on the first turn of every session,
    // in the surface itself, and not disableable by a tenant.
    const disclosure = session.disclosureShown ? undefined : await this.showDisclosure(session, config);

    // --- Kill switch, evaluated before the model is called at all.
    if (config.killSwitch === 'BOOKING_LINK_ONLY') {
      return this.degraded(session, config, disclosure, catalogue);
    }

    // --- Steps 2 and 3. Retrieval runs as a tool so it passes the same gate as
    // everything else; the model decides what to look up.
    let output: ModelTurnOutput;
    try {
      output = await this.deps.model.turn({
        systemPrompt: buildSystemPrompt(config),
        history: session.history,
        visitorInput: input.visitorInput,
        tools: catalogue,
        config,
      });
    } catch (cause) {
      // Degrade, never fail (section 8.1).
      await this.deps.audit.write({
        tenantId: session.tenantId, type: 'tool_call_failed',
        correlationId: session.correlationId, sessionId: session.id, actor: 'system',
        payload: { stage: 'model', message: String(cause) },
      });
      return {
        text: 'I am having trouble at my end. Rather than keep you waiting, let me get someone from the team to pick this up.',
        disclosure,
        toolsExecuted: [], toolsDenied: [], escalated: true,
        outputViolations: [], injectionDetected: injection.detected,
        correlationId: session.correlationId,
      };
    }

    await this.deps.metering.record(session.tenantId, 'llm_token', output.tokensUsed);
    await this.deps.metering.record(session.tenantId, 'text_message', 1);

    session.consecutiveNegativeTurns = output.sentiment === 'negative' ? session.consecutiveNegativeTurns + 1 : 0;

    // --- Steps 4 to 8, per proposed tool call.
    const executed: string[] = [];
    const denied: { tool: string; reason: string }[] = [];
    let retrievedText = '';

    let referenceEnvelope: string | undefined;

    for (const call of output.toolCalls) {
      try {
        const result = await this.deps.executor.execute(session, config, catalogue, call as ProposedToolCall);
        executed.push(call.tool);
        const text = result.internal?.['retrievedText'];
        if (typeof text === 'string') retrievedText += ` ${text}`;
        const reference = result.modelVisible?.['reference'];
        if (typeof reference === 'string') referenceEnvelope = reference;
      } catch (cause) {
        const error = isAwaError(cause) ? cause : new AwaError({ kind: 'INTERNAL', message: String(cause), cause });
        denied.push({ tool: call.tool, reason: error.kind });
      }
    }

    // --- Step 3, again, now that step 2 has actually happened.
    //
    // The model chooses what to look up, so retrieval cannot run before the
    // first turn. But the answer has to be composed *from* what was retrieved,
    // and without this pass the retrieved material never reaches the model at
    // all: it looked knowledge up and then answered from nothing, which is the
    // one thing the product promises it does not do.
    //
    // Tool calls proposed by this second turn are not executed. The turn exists
    // to compose an answer from material already gathered under policy, and
    // letting it call tools again would be an unbounded loop with a fresh set
    // of side effects at every step.
    if (referenceEnvelope) {
      try {
        const grounded = await this.deps.model.turn({
          systemPrompt: buildSystemPrompt(config),
          history: session.history,
          visitorInput: input.visitorInput,
          referenceEnvelope,
          tools: catalogue,
          config,
        });
        await this.deps.metering.record(session.tenantId, 'llm_token', grounded.tokensUsed);
        output = { ...grounded, toolCalls: [] };
      } catch {
        // Keep the first turn's answer. A failure here costs grounding, not
        // the conversation.
      }
    }

    // --- Escalation. The model recognises the signal; the platform decides.
    const escalation = evaluateEscalation(config.escalation, {
      modelConfidence: output.confidence,
      factualQuestion: /\?$/.test(input.visitorInput.trim()),
      consecutiveNegativeTurns: session.consecutiveNegativeTurns,
      detectedTopics: output.detectedTopics,
      classification: session.classification,
      visitorAskedForHuman: session.humanRequested,
      securityClassifierFired: injection.detected,
    });

    if (escalation.escalate && !executed.includes('escalate_to_human')) {
      try {
        await this.deps.executor.execute(session, config, catalogue, {
          tool: 'escalate_to_human',
          args: { reason: escalation.triggers[0] ?? 'low_confidence', summary: summarise(session) },
        });
        executed.push('escalate_to_human');
      } catch {
        // Escalation is never blocked by policy, but a store failure must not
        // take the conversation down with it.
      }
    }

    // --- Step 9: output validation before anything reaches the visitor.
    //
    // Ordering matters here. An injection attempt suppresses the model's text
    // unconditionally, before validation and independently of whether the turn
    // also escalated: refuse, log, continue. An earlier version applied this
    // only when the turn had not escalated, which meant an injection that also
    // tripped the security escalation trigger let the model's own text through.
    let text: string;
    if (injection.detected) {
      text = 'I can only help with questions about what we do. What are you looking for?';
    } else if (escalation.answerSuppressed) {
      text = 'I would rather not answer that from guesswork. Let me get someone who can answer it properly.';
    } else {
      text = output.text;
    }

    const verdict = validateOutput({
      text,
      config,
      approvedFigures: approvedFigures(config),
      retrievedText,
    });

    if (!verdict.allowed) {
      await this.deps.audit.write({
        tenantId: session.tenantId, type: 'output_blocked',
        correlationId: session.correlationId, sessionId: session.id, actor: 'policy',
        payload: { violations: verdict.violations, notes: verdict.notes },
        versions: session.versions,
      });
      text = BLOCKED_OUTPUT_REPLACEMENT;
    } else {
      text = verdict.text;
    }

    // --- Step 10: emit.
    this.deps.sessions.record(session, 'assistant', text);
    if (session.state === 'Engaged' || session.state === 'NonResolving' || session.state === 'Resolving') {
      this.advance(session);
    }

    return {
      text,
      disclosure,
      toolsExecuted: executed,
      toolsDenied: denied,
      escalated: escalation.escalate,
      outputViolations: verdict.violations,
      injectionDetected: injection.detected,
      correlationId: session.correlationId,
    };
  }

  private async showDisclosure(session: Session, config: TenantConfig): Promise<string> {
    const text = session.modality === 'voice' ? config.disclosure.voiceText : config.disclosure.text;
    session.disclosureShown = true;
    await this.deps.audit.write({
      tenantId: session.tenantId, type: 'disclosure_shown',
      correlationId: session.correlationId, sessionId: session.id, actor: 'system',
      payload: { modality: session.modality, wording: text },
      versions: session.versions,
    });
    return text;
  }

  /** Booking-link-only mode. Honest about the limitation; still useful. */
  private async degraded(
    session: Session,
    config: TenantConfig,
    disclosure: string | undefined,
    catalogue: readonly ToolDefinition[],
  ): Promise<TurnResult> {
    await this.deps.audit.write({
      tenantId: session.tenantId, type: 'kill_switch_engaged',
      correlationId: session.correlationId, sessionId: session.id, actor: 'system',
      payload: { mode: config.killSwitch },
    });
    void catalogue;
    const link = config.bookingLinkUrl ? ` You can book a time here: ${config.bookingLinkUrl}` : '';
    return {
      text: `I am not able to chat properly right now.${link} Someone from the team will be able to help.`,
      disclosure,
      toolsExecuted: [], toolsDenied: [], escalated: false,
      outputViolations: [], injectionDetected: false,
      correlationId: session.correlationId,
    };
  }

  private advance(session: Session): void {
    if (session.state === 'Engaged') {
      // Consent state decides the branch. NonResolving is a full path, not a
      // penalty: it qualifies and books without touching a CRM.
      this.deps.sessions.transition(session, session.classification ? 'Consented' : 'NonResolving');
    }
    if (session.state === 'Consented') this.deps.sessions.transition(session, 'Resolving');
    if (session.state === 'Resolving' || session.state === 'NonResolving') {
      this.deps.sessions.transition(session, 'Qualifying');
    }
  }
}

function summarise(session: Session): string {
  const captured = Object.entries(session.qualification.captured)
    .map(([key, value]) => `${key}: ${String(value)}`)
    .join('; ');
  return `Conversation ${session.id}. Captured: ${captured || 'nothing yet'}. Turns: ${session.history.length}.`;
}
