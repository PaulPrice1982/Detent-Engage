import type { KnowledgeChunk, KnowledgeCorpus } from './corpus.js';

/**
 * Retrieval with tenant binding applied at query construction (section 24.2).
 *
 * The scoring is BM25-style lexical matching over the published corpus. That is
 * a deliberate choice for the governed layer: it is deterministic, it explains
 * itself, and the retrieval abstraction can be swapped for the conversational
 * vendor's integrated vector search without any caller changing (table 20).
 */
export interface RetrievedChunk {
  readonly chunk: KnowledgeChunk;
  readonly score: number;
}

export interface RetrievalOptions {
  readonly limit?: number;
  readonly minScore?: number;
}

const STOP_WORDS = new Set([
  'the', 'a', 'an', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 'be', 'been',
  'to', 'of', 'in', 'on', 'for', 'with', 'at', 'by', 'from', 'as', 'it', 'this',
  'that', 'do', 'does', 'did', 'can', 'could', 'you', 'your', 'we', 'our', 'i',
]);

export function tokenise(text: string): string[] {
  return text
    .toLowerCase()
    .split(/[^a-z0-9£$€%+.-]+/)
    .filter((token) => token.length > 1 && !STOP_WORDS.has(token));
}

export class RetrievalService {
  constructor(private readonly corpus: KnowledgeCorpus) {}

  /**
   * Retrieve for one tenant. There is no overload that omits the tenant id and
   * no default: a caller that forgets it does not compile.
   */
  retrieve(tenantId: string, query: string, options: RetrievalOptions = {}): RetrievedChunk[] {
    const chunks = this.corpus.published(tenantId);
    if (chunks.length === 0) return [];

    const queryTokens = tokenise(query);
    if (queryTokens.length === 0) return [];

    const documentFrequency = new Map<string, number>();
    const documentTokens = chunks.map((chunk) => {
      const tokens = tokenise(`${chunk.title} ${chunk.text}`);
      for (const token of new Set(tokens)) {
        documentFrequency.set(token, (documentFrequency.get(token) ?? 0) + 1);
      }
      return tokens;
    });

    const averageLength = documentTokens.reduce((sum, tokens) => sum + tokens.length, 0) / documentTokens.length;
    const k1 = 1.2;
    const b = 0.75;

    const scored = chunks.map((chunk, index) => {
      const tokens = documentTokens[index]!;
      const counts = new Map<string, number>();
      for (const token of tokens) counts.set(token, (counts.get(token) ?? 0) + 1);

      let score = 0;
      for (const queryToken of queryTokens) {
        const frequency = counts.get(queryToken);
        if (!frequency) continue;
        const df = documentFrequency.get(queryToken) ?? 1;
        const idf = Math.log(1 + (chunks.length - df + 0.5) / (df + 0.5));
        const denominator = frequency + k1 * (1 - b + (b * tokens.length) / (averageLength || 1));
        score += idf * ((frequency * (k1 + 1)) / denominator);
      }
      return { chunk, score: Math.round(score * 1000) / 1000 };
    });

    const minScore = options.minScore ?? 0.15;
    return scored
      .filter((result) => result.score >= minScore)
      .sort((a, b2) => b2.score - a.score)
      .slice(0, options.limit ?? 4);
  }
}
