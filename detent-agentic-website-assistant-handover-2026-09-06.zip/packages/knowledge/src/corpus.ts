import { WriteQueue, newId, type Clock, systemClock } from '@detent/awa-core';

/**
 * Governed ingestion (section 15).
 *
 * Three rules are enforced structurally rather than by process discipline:
 * content enters as a DRAFT and must be approved by the tenant before it is
 * served; every published change is versioned and attributed, so "why did it
 * say that in March" is answerable; and unshipped capability is excluded from
 * the corpus entirely, because an assistant that can retrieve a roadmap item
 * will eventually sell it.
 */
export type ChunkState = 'DRAFT' | 'PUBLISHED' | 'RETIRED';

export type SourceKind = 'uploaded_document' | 'approved_page' | 'service_catalogue' | 'faq' | 'case_study';

export interface KnowledgeChunk {
  readonly id: string;
  readonly tenantId: string;
  readonly corpusVersion: number;
  readonly state: ChunkState;
  readonly sourceKind: SourceKind;
  readonly sourceRef: string;
  readonly title: string;
  readonly text: string;
  /** Set by the tenant. Unshipped material is refused at ingestion. */
  readonly shipped: boolean;
  readonly approvedBy?: string;
  readonly approvedAt?: string;
  readonly createdAt: string;
  readonly supersedes?: string;
}

export interface IngestInput {
  readonly tenantId: string;
  readonly sourceKind: SourceKind;
  readonly sourceRef: string;
  readonly title: string;
  readonly text: string;
  readonly shipped: boolean;
}

/**
 * Somewhere a chunk is kept beyond this process.
 *
 * The corpus itself stays in memory and stays synchronous, because retrieval
 * runs on it inside a conversation turn and making that path asynchronous
 * would spread through every caller for no gain. Durability is added around
 * it instead: every change is written through to the archive, and the corpus
 * is rehydrated from the archive at boot.
 *
 * That is the usual arrangement for a search index, and it has the usual
 * limitation, stated rather than discovered: the corpus must fit in memory,
 * and a second instance of the process learns about a change only when it
 * next loads. For FAQ-sized knowledge on one instance, neither bites.
 */
export interface KnowledgeArchive {
  /** Called after every ingest, publish and retire. Failures are surfaced. */
  save(chunk: KnowledgeChunk): Promise<void>;
  /**
   * One tenant's chunks, for rehydration at boot.
   *
   * Per tenant rather than all at once, and that is a security constraint
   * rather than a preference. Knowledge is a customer's own material and the
   * table carries FORCE ROW LEVEL SECURITY, so a query has to name the tenant
   * it is reading for. A loadAll that read every tenant's rows in one
   * statement could only work by being exempt from the policy, and an
   * exemption used at every boot is not a policy.
   */
  loadFor(tenantId: string): Promise<readonly KnowledgeChunk[]>;
}

export class KnowledgeCorpus {
  private readonly chunks = new Map<string, KnowledgeChunk[]>();
  private readonly versions = new Map<string, number>();
  private readonly writes = new WriteQueue();

  constructor(
    private readonly clock: Clock = systemClock,
    private readonly archive?: KnowledgeArchive,
  ) {}

  /**
   * Fills the corpus from the archive.
   *
   * Called once at boot, before anything serves. Without it a restart empties
   * every customer's knowledge and the assistant answers nothing, while
   * looking, from the outside, exactly like a customer who never uploaded
   * anything.
   */
  async rehydrate(tenantIds: readonly string[]): Promise<number> {
    if (!this.archive) return 0;
    const archive = this.archive;
    const loaded = await Promise.all(tenantIds.map((id) => archive.loadFor(id)));
    const stored = loaded.flat();
    this.chunks.clear();
    this.versions.clear();
    for (const chunk of stored) {
      const list = this.chunks.get(chunk.tenantId) ?? [];
      list.push(chunk);
      this.chunks.set(chunk.tenantId, list);
      // The version counter has to come back too, or the next publish reuses a
      // version number that already means something else.
      const seen = this.versions.get(chunk.tenantId) ?? 0;
      if (chunk.corpusVersion > seen) this.versions.set(chunk.tenantId, chunk.corpusVersion);
    }
    return stored.length;
  }

  /**
   * Writes a chunk through to the archive, if there is one.
   *
   * Deliberately not awaited by the synchronous callers: the corpus is the
   * source of truth for this process and the archive is how it survives. A
   * write that fails is reported rather than swallowed, because knowledge that
   * is live but unsaved is knowledge that disappears at the next restart with
   * no warning.
   */
  private persist(chunk: KnowledgeChunk): void {
    if (!this.archive) return;
    const archive = this.archive;
    // Queued per chunk, not fired and forgotten. Ingest writes a draft and
    // approval writes it published microseconds later; unordered, the draft
    // write can land last and revert an approved answer on disk while it
    // stays correct in memory.
    this.writes.run(chunk.id, () => archive.save(chunk), (error: unknown) => {
      console.error(
        `Knowledge archive: failed to save ${chunk.id} for ${chunk.tenantId}. `
        + 'It is live in this process and will be lost on restart. '
        + String(error instanceof Error ? error.message : error),
      );
    });
  }

  /** Waits for every queued write. For shutdown, and for tests. */
  async flush(): Promise<void> {
    await this.writes.drain();
  }

  /** Ingest as DRAFT. Nothing is servable until a named tenant user approves it. */
  ingest(input: IngestInput): KnowledgeChunk {
    if (!input.shipped) {
      // An unshipped capability never enters the corpus. Queries about it are
      // qualified and handed to a human instead (section 15, table 20).
      throw new Error('unshipped capability cannot be ingested; it must be excluded from the corpus');
    }
    const chunk: KnowledgeChunk = {
      id: newId('kc', this.clock.nowMs()),
      tenantId: input.tenantId,
      corpusVersion: this.versions.get(input.tenantId) ?? 0,
      state: 'DRAFT',
      sourceKind: input.sourceKind,
      sourceRef: input.sourceRef,
      title: input.title,
      text: input.text,
      shipped: true,
      createdAt: this.clock.iso(),
    };
    const list = this.chunks.get(input.tenantId) ?? [];
    list.push(chunk);
    this.chunks.set(input.tenantId, list);
    this.persist(chunk);
    return chunk;
  }

  /** Publish a draft. Bumps the corpus version so a rollback target exists. */
  publish(tenantId: string, chunkId: string, approvedBy: string): KnowledgeChunk {
    const list = this.chunks.get(tenantId) ?? [];
    const index = list.findIndex((chunk) => chunk.id === chunkId);
    if (index < 0) throw new Error(`chunk ${chunkId} not found for tenant ${tenantId}`);

    const version = (this.versions.get(tenantId) ?? 0) + 1;
    this.versions.set(tenantId, version);

    const published: KnowledgeChunk = {
      ...list[index]!,
      state: 'PUBLISHED',
      corpusVersion: version,
      approvedBy,
      approvedAt: this.clock.iso(),
    };
    list[index] = published;
    this.persist(published);
    return published;
  }

  retire(tenantId: string, chunkId: string): void {
    const list = this.chunks.get(tenantId) ?? [];
    const index = list.findIndex((chunk) => chunk.id === chunkId);
    if (index >= 0) {
      list[index] = { ...list[index]!, state: 'RETIRED' };
      this.persist(list[index]!);
    }
  }

  /**
   * Read published chunks for exactly one tenant. The tenant id is a required
   * argument, not an optional filter, binding at query construction rather
   * than post-filtering is what makes cross-tenant isolation testable.
   */
  published(tenantId: string): KnowledgeChunk[] {
    return (this.chunks.get(tenantId) ?? []).filter((chunk) => chunk.state === 'PUBLISHED');
  }

  version(tenantId: string): number {
    return this.versions.get(tenantId) ?? 0;
  }

  all(tenantId: string): KnowledgeChunk[] {
    return [...(this.chunks.get(tenantId) ?? [])];
  }

  /**
   * Keeps this process's index in step with the others.
   *
   * The index is in memory and was filled once, at boot. On one instance that
   * is exactly right. On an autoscaling deployment it is a correctness fault:
   * knowledge approved on one instance is invisible to the other two until they
   * happen to restart, so a customer publishes an answer, tests it, and gets
   * "I do not know" from roughly two requests in three. That is worse than not
   * having the feature, because it looks like the assistant is unreliable
   * rather than like the platform is misconfigured.
   *
   * A periodic reload rather than a shared cache, because the honest shape of
   * the guarantee is eventual consistency within a stated window, and a window
   * of a minute is invisible to somebody who has just approved something and is
   * about to go and test it. `published` and `all` are read inside a
   * conversation turn and stay synchronous: making them async to check a
   * watermark would put a database round trip in the middle of every answer.
   *
   * The timer is unrefed, so it never holds the process open at shutdown.
   */
  startRefreshing(options: {
    readonly intervalMs: number;
    readonly tenants: () => readonly string[];
    readonly onError?: (error: unknown) => void;
  }): () => void {
    const timer = setInterval(() => {
      void this.rehydrate(options.tenants()).catch((error: unknown) => {
        // Never fatal. A refresh that fails leaves the index as it was, which
        // is stale rather than empty, and stale beats gone.
        options.onError?.(error);
      });
    }, options.intervalMs);
    timer.unref?.();
    return () => clearInterval(timer);
  }
}
