# Working agreement, Detent Agentic Website Assistant

## Standing instruction: deliver a zip and a Replit prompt on every change

**This applies to every change, without being asked again.** After any change is
committed and pushed, produce both:

1. `dist-zip/detent-agentic-website-assistant.zip`: the full source, built from a
   pristine `git ls-files` copy so no build artefact can leak in.
2. `REPLIT-PROMPT.md`, rewritten for *that specific change*, not a generic
   rebuild prompt.

Send both to the user. Do not wait to be asked.

### How the user's Replit actually receives an update

Verified against the live container, not assumed:

- The Replit workspace (`Detent Agentic Assistant`, `/home/runner/workspace/`)
  is **not a git checkout**. It has no remote, so `git pull` fails with
  `fatal: 'origin' does not appear to be a git repository`.
- Its **root is the contents of `agentic-website-assistant/`**, which in this
  repo is a subdirectory. So even with a remote added, a pull would land the
  files one level down and break the layout.

**Therefore the zip is the delivery mechanism, not a fallback.** Do not write a
`git pull` route into the Replit prompt. The instruction is: unzip over the
workspace, then run the preflight.

A git route would need either a repo restructure putting the app at the root, or
a sparse checkout plus a token for a private repo. Neither is worth it while a
drag-and-drop costs nothing; revisit when there are multiple sites to update.

### The objective: minimise Replit credit burn without compromising the build

Replit charges per **Agent** request. The Shell is free. So every prompt written
here is judged on one question: how few Agent requests does it take to get from
the current state to verified green?

Rules, in priority order:

1. **Prefer the Shell over the Agent.** If a step can be a shell command, it must
   be a shell command. Applying the zip and running the preflight in the Shell
   costs nothing; the Agent costs a request every time it reads or retries.
2. **Never let the Agent think it is building.** It must be told, in the first
   line, that the repository is finished, typechecked and tested, and that it is
   there to run it, not to write it. An Agent that decides to refactor
   `packages/core` costs twice: once to do it, once to undo it.
3. **State the expected output of every command**, but state it as a
   *property*, not as a number that will go stale. An Agent that cannot tell
   success from failure will retry, and every retry is a request.

   "Ends with `Tests N passed` and no `failed`" survives the next release.
   "Ends with `Tests 804 passed`" does not: the count changed the same day it
   was written, and a correct build was stopped and reported as a mismatch
   because the prompt disagreed with the code shipped beside it. The Agent was
   right to stop: the prompt was wrong. Quote a current number only as a
   reference point, and say plainly which way a difference matters: more tests
   is a later release, fewer files means the zip did not fully apply.
4. **Name what must not be touched.** Source, tests, dependencies and migrations
   are off limits.
5. **Give an explicit stop condition.** "Report the output and STOP." Without it
   the Agent keeps going and keeps charging.
6. **Never buy a green test run with a weakened test.** Credit efficiency never
   justifies deleting, skipping or loosening a test. If the suite fails, the
   Agent stops and reports; it does not "fix" the suite.
7. **State a realistic request budget** and the point at which the user should
   drop back to the Shell.

### Build the zip like this

Verify in a throwaway copy, never in place: an in-place `tsc --build` leaves
`dist/` and `.tsbuildinfo` behind and they end up in the zip. Then zip from a
second copy populated only from `git ls-files`. Confirm the file count and that
no `dist/`, `node_modules/` or `*.tsbuildinfo` is present before sending.

## House style

No dashes, in copy or in comments: no em dash, en dash, figure dash, horizontal
bar or minus sign. `tests/no-em-dashes.test.ts` enforces it.

It checks the escaped and entity spellings too, because the first version looked
for one literal character and 31 dashes went past it written three other ways: a
JavaScript escape, an HTML entity, and a numeric character reference.
Twenty-three were in the marketing copy, so the site
carried dashes on every page while the test was green. A gate that checks the
shape of a thing rather than the thing itself is worse than no gate, because it
is believed.

Do not replace one with a hyphen. An em dash usually wants a comma, a colon or
a full stop, and a hyphen in its place leaves a sentence that reads as though
something went wrong in a text editor. Where the dashes came in a pair around a
list, brackets are right, because commas around a list of commas is unreadable.

One file is exempt and stays exempt: the price-range regex in
`packages/onboarding/src/extraction.ts` matches a range as a visitor typed it,
and people type ranges with whichever dash their keyboard produced.

## Shipped copy lives in the database, so it needs a revision

The marketing copy ships in `packages/server/src/marketing-seed.ts` and is
stored in Postgres. The seed used to run only when the site had no pages at all,
so the wording the first deployment created was the wording for ever: three
releases rewrote the home page and the live site showed none of it, which was
reported as "the text still says the old thing".

`MARKETING_COPY_REVISION` fixes that and **must be bumped whenever the copy in
that file changes**, or the change reaches nobody. `PageService.reseed`
republishes a page the seed still owns and never touches one a person has edited
in the console; the boot log says which it did for each page.

Checking the source for a change is therefore not checking the site. The
question is always what revision the deployment is on.

## Engineering constraints that do not change

- Development API keys are printed once at boot and stored only as SHA-256
  digests. Never plaintext, never in a log.
- The platform never holds a card number. PSP token references only.
- Credentials never enter model context, a prompt, or a log line.
- Postgres RLS binding uses `SET LOCAL app.tenant_id`, never a plain `SET`: a
  plain `SET` survives the transaction back into the pooled connection and
  becomes the next request's tenant context.
- **vitest is not a dependency and must not become one.** It was the sole source
  of every vulnerability a deployment scan reported, including a critical one
  (arbitrary file read and execution through its UI server), and it dragged in
  around 240 transitive packages for a tool that never runs in production. The
  tests run on `tools/mini-test.ts`, which is why that exists. A developer who
  wants watch mode installs it themselves; the tests import from "vitest" and
  `tests/tsconfig.json` maps that specifier to the built-in runner.
- Run `pnpm audit` before shipping. A hosting platform blocks a deploy on a
  critical advisory, and the finding is in the dependency tree rather than
  anything in the diff.
- The server binds `0.0.0.0`. A loopback bind leaves the process healthy and
  unreachable, which a preview proxy reports as "running, but the preview isn't
  ready".
- One test file per CI gate. A test is changed only when the test is wrong, and
  the reason is stated.
- **A test must judge the release, not the folder it is sitting in.** Never
  enumerate files with `git ls-files` or a bare directory walk from the root: on
  the hosting platform the source sits beside that platform's own files and
  every archive anybody has uploaded next to it, and a gate that fails on those
  stops a correct build. It has happened twice. Walk the directories this
  release owns and skip everything else.
- A gate that stops good releases gets switched off, and then it is catching
  nothing. Weigh that against what the gate is for before adding one.

## The workspace is not the live site

Applying a zip and restarting the workflow changes the Replit **workspace**. The
published site goes on serving the last build that was published until somebody
presses Republish. Four releases were applied and verified in the workspace
while the owner was testing a live site running a build from before any of them,
and every report of "still broken" was accurate.

So a verification in the workspace is not evidence about the live site, and the
Replit prompt's last step is Republish, not the tests.

`/health` carries `copyRevision` and `consoleHere` on every hostname, which
makes "which build is this address serving, and is the console on it" one curl
against any URL. `copyRevision` is the same number the copy release uses, so it
cannot go stale the way a hand-written version string does, and a build older
than that mechanism does not return the field at all.

## A migration is run again, whether you meant it to be or not

Every migration file is written to be safe to run twice, and none of them
manages its own transaction. The runner wraps each file together with the row
recording it, so either both land or neither does.

Both rules were learned the hard way. The files opened with `BEGIN;` and ended
with `COMMIT;`, which ended the runner's transaction early: a failure after that
left the schema committed and the ledger row missing, and every start after it
re-ran a migration whose tables already existed. The live site sat on
`relation "tenant" already exists` and the only way out would have been typing
SQL into production. With idempotent SQL the same database is adopted at the
next start with no intervention and no data touched.

`tests/migrations.test.ts` holds both rules. Behaviour was verified against a
real PostgreSQL put into exactly that broken state, which is the check to repeat
before changing anything in `db/migrations`.

## Row level security applies to the application, and not to a superuser

Every table in `0001_init.sql` carries `FORCE ROW LEVEL SECURITY` and a policy
of `tenant_id = current_setting('app.tenant_id', true)`. A superuser bypasses
row level security entirely; a managed PostgreSQL hands the application an
ordinary owner role, and an owner is exactly who FORCE exists to constrain.

So a query that does not bind the tenant reads nothing and writes are refused
with "new row violates row-level security policy". That was live: the audit
trail could not be written on the deployed platform while every local test
passed as `postgres`.

**Bind the tenant with `Database.queryAs(tenantId, ...)` for every statement
against a tenant-scoped table.** Anything that needs to read across tenants is
either wrong or belongs to a table that is not tenant-scoped: the tenant
registry is the one such table, and it was taken out of row level security in
`0003` rather than given a policy with a hole in it.

Run the database tests as a non-superuser or they prove nothing:

```
createuser appowner; createdb -O appowner detent_test
TEST_DATABASE_URL=postgres://appowner@localhost/detent_test node tools/test.mjs
```

`tests/durable-stores.test.ts` says the same thing at the top of the file.

## Reproduce on the platform's hostname, not on a laptop

`REPLIT_DEV_DOMAIN` in the workspace and `REPLIT_DOMAINS` in a deployment put a
platform hostname into the host config, and `resolveSite` takes that branch
before the development path-prefix branch. A laptop has neither, so it takes a
different branch entirely.

That difference hid a dead back office through three rounds of "the sign in page
is not working": `/console` resolved to the marketing site, and therefore its
404, everywhere a platform hostname exists, which is every Replit workspace and
every deployment and no laptop. Every local test passed.

So when a fault is reported on Replit and does not reproduce, set
`REPLIT_DEV_DOMAIN` and send the matching `Host` header before concluding
anything:

```
REPLIT_DEV_DOMAIN=x.picard.replit.dev PORT=8893 node tools/serve.mjs
curl -H 'Host: x.picard.replit.dev' localhost:8893/console/signin
```

`tests/health-checks.test.ts` holds every hostname case, including this one.

## The site router must not own paths that are files

`packages/server/src/main.ts` hands anything whose last segment contains a dot
to the static handler. It used to be an allowlist of four directory prefixes,
and every asset at the root fell outside it: `/og-image.png`, `/favicon.svg` and
`/apple-touch-icon.png` were declared in the head of every page and all three
answered with the marketing 404. That is most of what an automated SEO check
looks at, and it rated the site weak twice before anybody looked at the actual
response.

A marketing slug never contains a dot, so the rule is the file name rather than
a list somebody has to remember to extend. `tests/seo.test.ts` asserts that
every asset the head promises exists on disk and is still referenced.

## What is durable, and what a deployment needs set

Everything the platform holds is Postgres-backed: accounts, sessions, billing,
pages, resellers, support, the audit trail, knowledge, tenants, and (since the
review) metering, consent, outcomes, payments, write receipts, CRM connections
and the suppression list. On a laptop with no `DATABASE_URL` every one of them
falls back to memory and the boot banner says so.

Two secrets change behaviour rather than enabling a feature:

- `DETENT_CREDENTIAL_KEY`, 32 bytes of base64 (`openssl rand -base64 32`).
  Without it a customer's CRM token is kept in memory rather than written in
  clear, so every customer reconnects their CRM after a deploy. Rotating it
  makes stored credentials unreadable, which reads as "not connected" and logs
  a line naming the tenant; it never fails a conversation.
- `STRIPE_SECRET_KEY` **and** `STRIPE_WEBHOOK_SECRET`. Both or neither: a key
  that can take money but cannot verify what the provider says happened to it
  is worse than not taking money. With neither, the sandbox provider runs and
  the banner says no card is ever charged.

The knowledge index is in memory and refreshed from the archive every 60
seconds (`DETENT_KNOWLEDGE_REFRESH_MS`). That is what makes an autoscale
deployment correct: without it, knowledge approved on one instance is invisible
to the others until they restart.

## An optional secret never takes the site down

A missing or malformed optional credential disables the feature it belongs to,
loudly, and takes nothing else with it. Everything in this platform followed
that rule except one thing, and the exception cost a working site: a mistyped
`DETENT_CREDENTIAL_KEY` was treated as a refusal, and one wrong secret took down
the marketing site, the customer app and the console, none of which need that
key for anything.

The reasoning behind the refusal was not wrong (somebody who set the secret
meant credentials to be encrypted, and carrying on quietly is the opposite of
what they asked for) but the consequence was. The answer is to be loud, not to
be fatal. `refusals` is for a state where serving would be incorrect or unsafe,
which is a database that is set and unreachable, or a console sharing a hostname
with a customer domain. It is not for a feature that can be switched off.

**Fix the class, not the instance.** This was fixed for the credential key and
not for the session secret, so the same fault stopped the same application one
release later over a value that only signs a cookie. When one of these turns up,
grep the boot path for every other `throw` reachable from an environment value
and fix all of them in the same change. `tests/optional-secrets.test.ts` covers
every optional secret rather than the one that bit.

The message matters as much as the behaviour. Base64 decoding ignores every
character that is not base64, so pasting `openssl rand -base64 32` instead of
its output decodes to fifteen bytes rather than failing, and a message reading
"must be 32 bytes, this one decodes to 15" describes a symptom while hiding the
cause: it sent somebody looking for a truncated key twice. Validate the shape,
recognise the likely mistake, and name it. `tests/optional-secrets.test.ts`.

## Check the link, not the path

"Sign in does not work" was reported five times. Four of those I answered by
curling `/console/signin` and `/app/signin`, which returned 200 every time,
because the fault was never in the routing. With no `DETENT_APP_HOST`
configured, every sign-in and sign-up link on the marketing site was written as
`http://localhost:8787/app/signin`, and localhost on a visitor's phone is that
visitor's own machine. Every link went nowhere for every visitor, while every
path answered correctly.

So when somebody says a page cannot be reached, read the href they would have
clicked before curling the path they would have arrived at. `appBaseUrl` is
relative unless the customer area has a hostname of its own, and
`tests/site-links.test.ts` fails on any rendered link containing localhost, a
loopback address or a port.

## Diagnosing a Replit failure

The account is connected via MCP. `list_apps`, `list_app_files` and
`read_app_file` are **read-only and cost no credits**, use them freely to see
what is actually on the container. `ask_question` and `update_app_using_prompt`
invoke the Replit Agent and **do cost a request**.

When a failure cannot be seen from here, one targeted `ask_question` asking for
raw console output is cheaper than another round of inference. Two rounds were
spent hardening against causes that were not the cause; one question found it.

Ask for the exact output, and tell the Agent explicitly not to edit, install or
fix anything, otherwise it will start work you did not ask for and charge for
it.

App: `Detent Agentic Assistant`, replId `b5035297-35ae-4f38-87dc-c5814fb508fd`.

## Credentials

The console sign-in address is set by `DETENT_CONSOLE_EMAIL`; the password by
`DETENT_CONSOLE_PASSWORD`, which is set in **Replit Secrets and nowhere else**.

Never write a password into source, a config file, a doc or a commit message.
This repository is zipped and sent to people, so a password in it is a password
in everyone's copy of it and in git history forever. When
`DETENT_CONSOLE_PASSWORD` is unset the server generates one and prints it once
at boot, which is the correct behaviour: a shipped default password survives
into production because nobody remembers it was meant to be temporary.

## Third-party credentials

Every external credential is read from the environment and never written into
source, a config file or a doc:

- `DETENT_CONSOLE_PASSWORD`: the back office sign-in.
- `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, payments.
- `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, Sign in with Google.
- `APPLE_CLIENT_ID`, `APPLE_TEAM_ID`, `APPLE_KEY_ID`, `APPLE_PRIVATE_KEY` , 
  Sign in with Apple. Apple's client secret is a short-lived ES256 JWT that has
  to be regenerated, not a static string.
- `DETENT_EMAIL_PROVIDER` (`resend` or `postmark`), `DETENT_EMAIL_API_KEY`,
  `DETENT_EMAIL_FROM`, sending real email. Unset, messages print to the console
  and say they were not sent.
- `DETENT_BASE_URL`: the public URL. Reset links are followed from a mail
  client, so a relative one is useless; unset, links point at localhost and the
  boot line says so.

In Replit these go in Secrets. A missing credential disables that feature with a
message; it never falls back to a default, because a shipped default credential
survives into production once nobody remembers it was temporary.

## Pricing

`PLAN_CATALOGUE` in `packages/billing/src/plans.ts` seeds version 1 of each plan
and is not the live catalogue. The live one is edited in the console and stored
as immutable versions. **A price change never alters what an existing customer
pays**: every subscription pins the plan version it was sold on and the fee it
was contracted at. Anything that would break that pinning is a bug, not a
feature request.

## Deploying

A deployed environment (`REPLIT_DEPLOYMENT=1`, `NODE_ENV=production`, or
`DETENT_DEPLOYED=true`) declines every development convenience, because on the
internet those conveniences are leaked credentials:

- No console operator exists without `DETENT_CONSOLE_PASSWORD`. Nothing is
  generated and nothing is written to disk, in any environment: the secret is
  the only place the password exists. The sign-in page says which secret to set.
  The customer app keeps serving regardless, refusing to start would take it
  down for a secret it does not need.
- It prints no API keys at boot.
- Secure cookies follow the deployment automatically.

### Nothing in the boot sequence may throw

The deployment crash looped twice with the explanation already written and
already deployed. Both times something above it threw first, so the process
died before it could serve the page that named the fault, and the host reported
only "built successfully but failed to start", which names nothing.

So in `packages/server/src/main.ts`, every step from reading the environment to
`server.listen` appends to `refusals` or is inside the try that serves them.
Migrations, rehydrating the stores and seeding the demo tenant all touch the
database, and a database that is set but unreachable is the commonest
deployment fault there is. A new step goes below the guard or inside the try;
it never goes above it.

`tests/boot-refusal.test.ts` is the gate. It starts the real server against an
unreachable `DATABASE_URL` and requires a 503 that says so, still running at
the end. It boots a process rather than calling a function because the fault is
an ordering fault, and no unit test can see what order things run in.

**Never use a provider's own key prefix in a fixture or an example**, not even
in a comment. A hosting platform runs a secret scan before it will publish, and
a string shaped like a real credential blocks the deploy: the scanner cannot
tell a fixture from a leak, and it is right not to try.

## Never write a credential to a file

An earlier design wrote a generated console password to `CONSOLE-PASSWORD.txt`
so it could be read without the console. It blocked publishing: a file named for
a password, containing a password, is exactly what a deployment security scan
exists to find, correctly. Do not reintroduce it, or any variant.

The same applies to archives. Old release zips left in the workspace are scanned
too, and one containing a fixture from before a fix is enough to fail a publish
that the current source would pass.
