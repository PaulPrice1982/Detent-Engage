# Replit, apply this update

**The repository is finished. It is typechecked and every test passes. You are
here to run it, not to write it.** Do not refactor, do not "improve" a package,
do not add a dependency, do not change a test.

Everything below runs in the **Shell**, which is free. The Agent costs a request
every time it reads a file or retries a command. Budget: **0 to 2 Agent
requests.** If a step fails, report the exact output and stop.

## This release fixes the sign-in link, which is the actual fault

Every "Sign in" and "Start free" link on the live site pointed at
`http://localhost:8787/app/signin`. Localhost on a visitor's phone is that
visitor's phone, so every link went nowhere for every visitor, while
`/app/signin` itself answered 200 the whole time. That is why five rounds of
curling paths found nothing.

The check for it is step 11 and it is one command. Do not skip it.

## If a previous attempt left the app not serving, read this

**No secret can stop this application any more.** A malformed
`DETENT_CREDENTIAL_KEY` or a `DETENT_SESSION_SECRET` that is too short each used
to refuse the boot and take down the marketing site, the customer app and the
console with it. Both now disable only what they are for, say so at the top of
the log and in the banner, and everything else serves.

Print a correct value for either with, in the **Shell**:

```bash
node tools/make-secret.mjs            # DETENT_CREDENTIAL_KEY
node tools/make-secret.mjs session    # DETENT_SESSION_SECRET
```

Each prints the value alone on one line. Paste that line into the secret field.
Paste the command anywhere and it is wrong.


A mistyped `DETENT_CREDENTIAL_KEY` used to stop the whole application: the
marketing site, the customer app and the console, none of which need that key.
It no longer can. A bad key now disables only CRM credential storage, says so at
the top of the log, and everything else serves.

If the workspace is down for that reason right now, either **delete that secret**
or set it correctly, restart, and it comes straight back. Do not republish while
it is down: the published site is healthy and a republish would replace it.

## Read this first: the workspace and the live site are two different things

Applying a zip changes the **workspace**. Restarting the workflow restarts the
**workspace**. Neither touches the published site at
`detent-agentic-assistant.replit.app`, which goes on serving the last build that
was published until somebody presses **Republish**.

Four releases of fixes have been applied to this workspace and verified working
in it, while the live site carried on serving a build from before any of them.
The owner has been testing the live site. So:

**This release is not delivered until step 12. Republishing is the job, not the
victory lap.**

One curl tells you which build any address is serving:

```bash
curl -s https://detent-agentic-assistant.replit.app/health
```

- `"copyRevision":6` and `"consoleHere":true`: the live site has this release.
- `copyRevision` missing, or a lower number: the live site is on an older build
  and every fix below is invisible to anyone using it.
- `"consoleHere":false`: the back office is not served at that address.

Run it against the workspace preview too. If the two disagree, the answer is
always Republish, never another patch.

---

## 1. Apply the zip (Shell)

Unzip `detent-agentic-website-assistant.zip` and copy its **contents** over the
workspace root. The workspace root is the contents of
`agentic-website-assistant/`, not a folder containing it.

```bash
cd ~/workspace
unzip -o detent-agentic-website-assistant.zip
cp -a detent-agentic-website-assistant/. .
rm -rf detent-agentic-website-assistant detent-agentic-website-assistant.zip
```

## 2. Remove anything a security scan will stop the deploy for (Shell)

```bash
rm -f CONSOLE-PASSWORD.txt
rm -rf attached_assets/*.zip
```

Both have blocked a publish before. A file named for a password is exactly what
a deployment scan exists to find, and an old release zip is scanned too: one
containing a fixture from before a fix fails a publish the current source
passes.

## 3. Install, build and test (Shell)

The widget is compiled for the browser as well as for Node, so the build has two
steps. **Do not skip the second**: without it `/widget/loader.js` does not exist
and the assistant does not appear on any page.

```bash
pnpm install
pnpm build          # runs tsc --build AND the widget browser build
pnpm audit
node tools/test.mjs
```

Expected, exactly:

- `pnpm build`: no output. Any output is an error.
- `pnpm audit`: `No known vulnerabilities found`.
- `node tools/test.mjs`: the last line reads `Tests  N passed` with **no
  `failed`**, and no line begins `FAIL`.

  **Judge it on failures, not on the count.** At the time of writing it is 45
  files and 853 tests, but that number changes with every release and a prompt
  quoting a stale one has stopped a perfectly good build twice. The number that
  matters is zero failures. A higher count is a later release, not a problem. A
  file count *below* 52 means the zip did not fully apply: check the extraction
  rather than the tests.

  One test in this release, `tests/boot-refusal.test.ts`, starts a second copy
  of the server on a spare port for about a second. That is expected.

If `pnpm audit` reports anything, **stop and report it**. A critical advisory
blocks the deploy, and the finding will be in the dependency tree rather than in
anything that changed here.

## 4. Set the secrets

In **Secrets**, not in a file, and not in this prompt:

| Secret | Needed for |
| --- | --- |
| `DATABASE_URL` | **Required in a deployment.** Postgres connection string. Set by Replit when you add a database. |
| `DETENT_SESSION_SECRET` | Signs session cookies. **At least 32 characters**; `node tools/make-secret.mjs session` prints 64. Unset or too short, one is generated per boot, everything works, and every customer is signed out at each restart. The banner says which. |
| `DETENT_CREDENTIAL_KEY` | **Optional.** Encrypts a customer's CRM token at rest. **Run `openssl rand -base64 32` in the Shell and paste the line it prints**, which is 44 characters ending in `=`. Pasting the command itself does not fail loudly, it decodes to 15 bytes, and the app now says so. Leave it unset if you would rather not deal with it: CRM tokens then stay in memory, nothing is written in clear, and everything else works. Once set, do not change it: a rotated key makes stored connections unreadable and every tenant reconnects. |
| `DETENT_CONSOLE_PASSWORD` | Back office sign-in. Without it no operator exists in a deployment. |
| `DETENT_CONSOLE_EMAIL` | The operator's address. |
| `DETENT_BASE_URL` | Absolute links in emails. Unset, password reset links point at localhost. |
| `DETENT_MARKETING_HOST` | `www.detent.co.uk`, **only once DNS points at this app.** Leave unset until then. |
| `DETENT_APP_HOST` | `www.detent.co.uk`: the customer area shares the public domain. Leave unset until DNS is live. |
| `DETENT_CONSOLE_HOST` | `app.detent.co.uk`: the back office, on its own hostname. Leave unset until DNS is live. |
| `DETENT_CONSOLE_ON_PLATFORM_HOST` | `true` **only** while there is no custom domain, so the back office is reachable at `/console` on the Replit URL. Remove it the day `DETENT_CONSOLE_HOST` starts resolving. |
| `DETENT_EMAIL_PROVIDER`, `DETENT_EMAIL_API_KEY`, `DETENT_EMAIL_FROM` | Sending real email. Unset, messages print to the console and say they were not sent. |
| `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` | Taking payment, and **both or neither**. Until both are set the sandbox provider runs and no card is ever charged, which the boot banner says. A key that can take money but cannot verify what the provider says happened to it is worse than not taking money. |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | Sign in with Google. |
| `APPLE_CLIENT_ID`, `APPLE_TEAM_ID`, `APPLE_KEY_ID`, `APPLE_PRIVATE_KEY` | Sign in with Apple. |

**Set the three host variables only once DNS actually points at this app.** The
Replit hostname is always served, so with them unset everything works at the
deployment URL. Set to a domain that does not yet resolve here, they are simply
hostnames nobody arrives on, and every request lands on the Replit hostname,
which those settings do not describe. The boot banner prints every hostname that
will be answered; compare it against the URL in the browser.

A deployment refuses to serve if `DETENT_CONSOLE_HOST` shares a hostname with
the marketing, customer or reseller surface. That is deliberate: sharing it
means the back office is reachable from a customer domain. It now says so on a
page rather than exiting.

## 5. Provision the database (Replit)

Add a **PostgreSQL** database from the Replit tools panel. It sets
`DATABASE_URL` for you. Nothing else to do: the app applies its own migrations
at boot and reports which it applied. Migrations are idempotent, so a redeploy
against an existing database applies nothing and says `up to date`.

## 6. Run it (Shell)

```bash
node tools/doctor.mjs      # checks the port is free and the runtime is right
pnpm start
```

Expect `Detent Agentic Website Assistant listening on 0.0.0.0:8787`, and these
lines, which are the ones worth reading:

```
  migrations       applied 0001_init.sql, 0002_platform.sql
  storage          Postgres, data survives a restart
  restored         1 tenants, 14 knowledge chunks
  hostnames        detent-agentic-assistant.replit.app
```

If instead it prints `Detent is not configured and is answering 503`, that is
this release working. **Open the deployment URL in a browser: the page names
every problem.** Do not restart it and do not change any code; fix what the page
names and start it again.

If `storage` says **IN MEMORY**, `DATABASE_URL` is not set. On a laptop that is
a warning. In a deployment it is one of the problems the 503 page lists.

## 7. Prove the crash loop cannot come back (Shell)

This is the check for this release. Start the app pointed at a database that is
not there, and confirm it stays up and explains itself instead of dying.

```bash
PORT=8899 DATABASE_URL='postgres://x:x@127.0.0.1:1/x' DETENT_DEPLOYED=true \
  node tools/serve.mjs &
sleep 8
curl -s localhost:8899/health
curl -s -o /dev/null -w "\npage %{http_code}\n" localhost:8899/
kill %1
```

Expected: `/health` returns **200** with JSON containing
`"status":"not_configured"` and a reason mentioning the database, and `/`
returns **200** with a page saying the same. The process is still running when
you kill it.

The 200 is deliberate, and it is the second half of this fix. Replit routes
traffic to a container only while `/` answers 200; a 503 there means the
platform refuses the deployment and you never see the explanation at all. Every
path other than `/` and `/health` still answers 503, and both carry an
`x-detent-status: not_configured` header, so nothing is pretending to be
healthy.

A crash, an exit, or `connection refused` is a failure of this release. Report
the exact output and stop.

## 8. Check the health check itself (Shell)

This is what was actually failing. Ask the running app for `/` on a hostname it
has never heard of, which is exactly what Replit's own health check does.

```bash
curl -s -o /dev/null -w "probe %{http_code}\n" -H 'Host: 10.0.0.7' http://localhost:8787/
curl -s -o /dev/null -w "page  %{http_code}\n" -H 'Host: 10.0.0.7' http://localhost:8787/pricing
```

Expected: `probe 200` and `page 404`. The first keeps the deployment alive; the
second is the security property, an unknown hostname is still served no content.

If `probe` is 404, the zip did not apply. Do not publish.

## 9. Check the database recovers (Shell)

This is what has the live site stopped. The fix adopts a database that already
carries the schema instead of refusing it, so there is nothing to do by hand.
Start the app and read the migration line:

```
  migrations       applied 0001_init.sql, 0002_platform.sql
  storage          Postgres, data survives a restart
  restored         1 tenants, 14 knowledge chunks
```

`applied` on the first start after this release is correct and expected: it is
recording migrations whose objects already exist, not recreating them. Start it
a second time and it must say `up to date`.

**Do not run any SQL by hand, and do not drop or recreate the database.** Every
row is kept. If the app still refuses, it will say why on its own page, so open
the URL rather than guessing, and report that text.

## 10. Check what the boot banner now tells you (Shell)

Four lines are new and each one answers a question that used to need a
developer:

```
  storage          Postgres, data survives a restart
  CRM credentials  encrypted with DETENT_CREDENTIAL_KEY
  payments         SANDBOX, no card is ever charged. Set STRIPE_SECRET_KEY ...
  restored         1 tenants, 14 knowledge chunks
```

`CRM credentials` saying `IN MEMORY` means the key is unset or not valid, and
every customer will reconnect their CRM after each deploy. If it says the key is
not valid, the reason is printed above the banner: the commonest cause by far is
pasting `openssl rand -base64 32` rather than the 44 character line it prints.
Neither state stops the release. `payments` saying
`SANDBOX` means the product cannot take money yet. Neither stops the release;
both are things to know.

## 11. Check the sign-in LINK, not just the page (Shell)

The page has always loaded. The link to it was the fault. Read what a visitor
would actually tap:

```bash
curl -s -H "Host: $REPLIT_DEV_DOMAIN" http://localhost:8787/ | grep -oE 'href="[^"]*sign[^"]*"' | sort -u
```

Expected, exactly:

```
href="/app/signin"
href="/app/signup"
```

Anything containing `localhost`, `127.0.0.1` or a port number is the fault
returning, and the zip did not apply. Then confirm the pages behind them:

## 11b. Check the sign-in pages load (Shell)

The fault you have reported three times. Test it on the hostname Replit actually
serves, not on localhost: that difference is the whole reason it survived.

```bash
HOST_HEADER=$(echo $REPLIT_DEV_DOMAIN)
curl -s -o /dev/null -w "console signin  %{http_code}\n" -H "Host: $HOST_HEADER" http://localhost:8787/console/signin
curl -s -o /dev/null -w "app signin      %{http_code}\n" -H "Host: $HOST_HEADER" http://localhost:8787/app/signin
curl -s -o /dev/null -w "reseller signin %{http_code}\n" -H "Host: $HOST_HEADER" http://localhost:8787/reseller/signin
curl -s -H "Host: $HOST_HEADER" http://localhost:8787/console/signin | grep -c 'name="password"'
```

All three must be **200**, and the last must print **1**. A `404` on the console
line means the zip did not apply.

Then open the preview in a browser and sign in at `/console` with
`DETENT_CONSOLE_EMAIL` and `DETENT_CONSOLE_PASSWORD`. The boot log now prints
the address it expects, under `console sign-in`. If sign-in is refused, compare
that printed address against what you are typing before anything else.

## 12. Check the copy actually changed (Shell)

The site's wording is in the database, not in the template, so this is the step
that proves the release arrived.

Start the app (step 6) and read the boot lines beginning `copy /`:

```
  copy /home         updated from the copy shipped in this release
  copy /become-a-reseller  updated from the copy shipped in this release
```

- `updated` or `created`: the new copy is live. Correct.
- `current`: already on this revision. Correct on a second start.
- `edited in the console, so this release left it alone`: somebody edited that
  page in the back office and **their words win**. Nothing is overwritten. If
  you want the shipped copy instead, delete the page in the console and restart.

Then confirm it by eye:

```bash
BASE=http://localhost:8787
curl -s $BASE/ | grep -c 'Nobody, which is today'      # the three-way comparison
curl -s -o /dev/null -w "privacy %{http_code}\n" $BASE/privacy
curl -s -o /dev/null -w "terms   %{http_code}\n" $BASE/terms
curl -s -o /dev/null -w "cookies %{http_code}\n" $BASE/cookies
curl -s $BASE/ | grep -c 'doing nothing'               # the lost revenue table
curl -s $BASE/ | grep -c 'does whatever the answer leads to'
```

All three must be **1 or more**. If any is `0` the copy did not apply.

And no dashes anywhere on the page. The check builds the characters rather than
containing them, so it can be pasted into any shell:

```bash
curl -s $BASE/ | python3 -c "import sys; t=sys.stdin.read(); print(sum(t.count(chr(c)) for c in (0x2013,0x2014,0x2015,0x2212)))"
```

Must print `0`.

## 13. Check the app itself (Shell)

```bash
BASE=http://localhost:8787
for a in /widget/loader.js /robots.txt /sitemap.xml /og-image.png /favicon.svg /apple-touch-icon.png; do
  curl -s -o /dev/null -w "$a %{http_code}\n" $BASE$a
done
curl -sD - -o /dev/null $BASE/ | grep -i content-security-policy
```

Every one must be **200**, and the home page policy must contain
`script-src 'self'`. The last three were 404 until this release, which is most
of why the SEO rating read weak: the head of every page promised a social
preview image and a favicon that did not answer.

Then open the app and confirm by eye:

1. The launcher appears bottom-right on the home page and opens a panel.
2. Ask it *"Do you work with Salesforce?"*: it answers with the CRM list.
3. Ask it *"What is the capital of Peru?"*: it says it does not know and offers
   a person. **If it answers this one, something is wrong.**
4. `/console` on the console host shows the sign-in; `/console` on the public
   host shows **Not found**.

## 14. Republish. This is the step that delivers the release.

Everything above changed the workspace. Nobody outside it has seen any of it.

Press **Republish** (Publishing, then Republish), wait for it to finish, and
then prove it landed:

```bash
curl -s https://detent-agentic-assistant.replit.app/health
curl -s -o /dev/null -w "live console signin %{http_code}\n" https://detent-agentic-assistant.replit.app/console/signin
```

Required: `"copyRevision":6`, `"consoleHere":true`, and `live console signin
200`.

If the publish fails, it now fails with a reason: the app answers `/` with 200
whatever is wrong, so open the live URL in a browser and read the page rather
than reading the build log. Report what it says and **STOP**.

Only when those three checks pass is this release delivered. Report the output
and **STOP**.

If the publish still fails its health check after all of this, do not change any
code. Open **Publishing, Logs** and send the raw output. The app now answers the
probe on any hostname and stays up through any start-up fault, so a failure past
this point is something the logs name and inference will not.

---

## What changed in this update

### The sign-in link pointed at the visitor's own machine

Reported five times as "sign in does not work", and it was never in the routing.
`/console/signin` and `/app/signin` answered 200 throughout. With no
`DETENT_APP_HOST` set, the marketing site wrote every sign-in and sign-up link
as `http://localhost:8787/app/signin`, which on anybody's phone is their own
phone.

Those links are now relative, so they resolve against whatever host served the
page. They were also stored in the database with localhost baked in, so the copy
revision is bumped; without that the fix would have reached nobody.

### An optional secret could stop the whole application, twice

A malformed `DETENT_CREDENTIAL_KEY` refused the boot, so the marketing site, the
customer app and the console all stopped, none of which need that key. It was
fixed, and the same fault then stopped the same application again over a
`DETENT_SESSION_SECRET` that was too short, because the fix was applied to the
instance and not to the class.

Both are now treated the same way an absent one is: the feature they belong to
is disabled or falls back, the operator is told loudly, and nothing else is
affected. Neither value is ever used when it is unusable. A test now covers
every optional secret rather than the one that bit.

A mistyped `DETENT_CREDENTIAL_KEY` refused the boot, so the marketing site, the
customer app and the console all stopped, none of which need that key. That was
wrong: everywhere else in this platform a missing or unusable optional
credential disables its own feature and takes nothing with it, and this is now
no exception. A bad key is reported at the top of the log and in the banner, CRM
connections stay in memory exactly as when no key is set, and nothing is written
in clear.

The message was part of the fault too. Base64 decoding ignores anything that is
not base64, so pasting the command decodes to 15 bytes rather than failing, and
"must be 32 bytes, this one decodes to 15" describes a symptom and hides the
cause. A value that looks like the command now says so.

### Row level security was refusing every tenant-scoped write

The largest fault, and it was invisible from the source. Every table in the
initial schema carries `FORCE ROW LEVEL SECURITY` with a policy requiring the
reader to name the tenant it is asking for, and the stores queried them without
naming one. A superuser bypasses row level security entirely, which is why every
local test passed; a managed PostgreSQL hands the application an ordinary owner
role, and an owner is exactly who that setting exists to constrain.

So on the deployed platform the audit trail could not be written at all, and the
knowledge corpus could not be read back. Every tenant-scoped statement now binds
the tenant for the transaction. Verified against a real PostgreSQL as a
non-superuser, which is the only way this is worth verifying.

### Seven stores were losing everything at every deploy

Metering, consent, outcomes, payments, write receipts, CRM connections and the
suppression list were all in memory. Three of those were compliance exposure
rather than inconvenience: consent evidence lasted until the next deploy while
the site told buyers the decision was recorded, an opt-out did not survive a
restart, and the metering the customer is billed from neither survived nor
agreed between instances.

All seven are durable. A customer's CRM token is encrypted at rest under
`DETENT_CREDENTIAL_KEY`, and a token that no longer decrypts reads as "not
connected" rather than failing every conversation.

### The product could not take money

The sandbox payment provider was hard-wired, so `STRIPE_SECRET_KEY` changed
nothing. Stripe is now used when both its secrets are set, and the boot banner
says which provider is live.

### Word and PDF uploads failed

The upload form invited them from the first release and nothing could read
either, so the first thing a new customer does was the first thing that failed.
Both are read now, with no new dependency. A scanned PDF is pictures of words
rather than words, and it says so instead of proposing nothing.

### Privacy, terms and cookies

Three new pages, seeded like every other page and editable in the console.
Written from what the software actually does: the cookies named are the cookies
the platform sets, and the sub-processors named are the services it calls.

**There is no cookie banner, and that is the finding rather than an omission.**
The platform sets three cookies, all session cookies for signed-in areas, and
the widget stores nothing at all on a visitor's device. Under PECR strictly
necessary cookies need clear information and no consent, so there is nothing to
ask about. The cookie page says so and explains why.

### The production database could not be migrated

The live site was stopped on `relation "tenant" already exists`. The migration
files opened their own transaction and committed it at the end, while the runner
also wrapped each file in a transaction together with the row that records it as
applied. The file's COMMIT ended the runner's transaction early, so a failure
after that point left the schema committed and the ledger row missing, and every
start since re-ran a migration whose tables already existed.

No migration manages its own transaction now, so a migration and the record of
it either both land or neither does. And every statement is safe to run again,
which is what lets the database you already have be adopted rather than refused:
tables and indexes with IF NOT EXISTS, triggers and policies dropped before
being created, and grants skipped where the role a managed database declined to
create does not exist. Tenant isolation is unchanged.

Verified against a real PostgreSQL in exactly that state: it adopts the
database, records both migrations, keeps every row, and the next start is a
no-op.

### The SEO rating was weak for a reason in the response

The head of every page declared `/og-image.png`, `/favicon.svg` and
`/apple-touch-icon.png`. All three answered 404, because the site router owned
every path outside four directory prefixes and every asset at the root fell
outside it. A social preview with no image and a site with no favicon is most of
what an automated check looks at. The router now hands anything whose name
contains a dot to the static handler, `apple-touch-icon.png` has been drawn from
the brand mark, and the meta description is 154 characters where it was 322.

### The back office could not be reached on Replit at all

`REPLIT_DEV_DOMAIN` in the workspace and `REPLIT_DOMAINS` in a deployment put a
platform hostname into the routing, and that branch was consulted before the
development one. It answered `/console` only when
`DETENT_CONSOLE_ON_PLATFORM_HOST` was set, so everywhere else the console fell
through to the marketing site and got its 404. A laptop has no platform
hostname, takes the other branch, and serves the console correctly, which is why
every local check passed while the sign-in page was dead in front of you.

The refusal was guarding a separation that did not exist yet. It exists once
`DETENT_CONSOLE_HOST` gives the console a hostname of its own; with none set
there is one hostname serving the whole app and refusing `/console` on it hid
the back office and protected nothing. The console is now served on the platform
hostname unless a dedicated console host says otherwise, and a customer domain
is unaffected: a request on `DETENT_MARKETING_HOST` or `DETENT_APP_HOST` never
reaches that branch and never serves the console.

If you do set `DETENT_CONSOLE_HOST` before its DNS resolves, `/console` here now
returns a page naming the setting that reaches it in the meantime, instead of a
marketing 404.

### The copy in the release never reached the site

The marketing copy ships in the code and is stored in the database. The seed ran
only when the site had no pages at all, so whatever wording the very first
deployment created stayed live for ever: three releases rewrote the home page
and the site went on showing the copy it was born with.

Each seeded page now carries the revision of the copy it came from. A newer
release replaces the page it seeded and republishes it; a page anybody has
edited in the back office is never touched, and the boot log says which happened
to each page. `MARKETING_COPY_REVISION` in `packages/server/src/marketing-seed.ts`
is what has to be bumped for a copy change to travel.

### The dashes were real, and the test that said otherwise was wrong

The gate searched for one literal character. Thirty-one dashes went past it
written as JavaScript escapes and HTML entities, twenty-three of them in the
marketing copy, so the site carried dashes on every page while the check was
green. Every one is now rewritten by hand (a comma, a colon, a full stop, or
brackets where a pair of dashes wrapped a list) and the gate checks every dash
character and every spelling of one, in `.js` and `.mjs` as well as `.ts`.

### A booked meeting was being sold as the outcome

It is now one outcome among several. The promise is the answer and whatever the
answer leads to: a booking where a booking is the point, and a quote, a stock
check or a callback where it is not.

### Nothing compared a person, Detent, and nobody

Two new sections. A three-way table across six dimensions (what a conversation
costs, when the question gets answered, covering the 128 hours a week you are
shut, what you know in the morning, what happens when the buyer was not ready,
what it costs to double the volume) against a person, against Detent, and
against nobody, which is what most businesses have quietly chosen. Then the
arithmetic: what one extra answered enquiry a night is worth at four average
sale values, against about a hundred pounds to answer thirty of them.

### The health check was being answered 404

Replit decides a container is alive by asking it for `/` and requiring a 200,
and it asks through its own proxy, on an internal hostname that is in no
`REPLIT_DOMAINS` and in nobody's configuration. In a deployment, every
hostname the app did not recognise resolved to no site and got a 404. So the
health check failed, Replit stopped routing to the container and restarted it,
and the same fault was reported three different ways across three builds:
"built successfully but failed to start", "the deployment is crash looping",
and "the deployment is failing health checks". The application was running and
answering every real hostname correctly the whole time.

An unknown hostname is still served no content, and that part is deliberate:
answering one with the real site is how a dangling DNS record becomes somebody
else's phishing page. It is now *answered*. The probe path gets a 200 and the
two characters `ok`, which tell an unknown caller nothing about what runs here.
Every other path is still `Not found`.

### The start-up explanation could not run

**The deployment also crash looped with the explanation already written and
already on the container.** The page that names a start-up problem existed and was
correct. It never ran, because everything that could fail ran above it:
applying migrations, reading the tenants and the knowledge corpus back out of
the database, and seeding the demo tenant. Every one of those touches the
database, and a database that is set but unreachable is the commonest
deployment fault there is. The first one to throw killed the process, Replit
restarted it, it threw again, and the only thing anybody saw was "built
successfully but failed to start", which names nothing.

Start-up now collects problems instead of throwing them:

- A migration that fails is a refusal in a deployment, and a warning on a
  laptop that then carries on in memory.
- A read that fails after the migration succeeded is a refusal that says so, so
  a database that went away mid-start does not look like a code fault.
- The entire build of the product sits inside a guard that falls back to the
  same page, so a fault anywhere in it is served rather than fatal.
- An unhandled rejection or an uncaught exception is named on the way out
  instead of leaving a bare stack trace.

`tests/health-checks.test.ts` holds both halves of the first fix: the unknown
hostname resolves to no site, and it is answered anyway.
`tests/boot-refusal.test.ts` is the gate for the second. It starts the
real server against an unreachable database and requires a 503 that says so,
still running at the end. It boots a process rather than calling a function
because the fault was an ordering fault, and no unit test can see what order
things run in.

Nothing else changed. No dependency was added, no route moved, and no existing
behaviour was altered.
