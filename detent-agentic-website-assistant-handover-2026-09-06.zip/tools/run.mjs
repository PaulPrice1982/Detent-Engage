/**
 * Run a TypeScript entry point with whatever this machine actually supports.
 *
 * Used by the demo and serve scripts so neither depends on a package a registry
 * might refuse to serve.
 */
import { runTypeScript } from './runtime.mjs';

const [entry, ...rest] = process.argv.slice(2);
if (!entry) {
  console.error('Usage: node tools/run.mjs <entry.ts> [args…]');
  process.exit(1);
}
process.exit(runTypeScript(entry, rest));
