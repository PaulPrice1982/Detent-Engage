/**
 * Starts the API server.
 *
 * Invoked directly by Node (`node tools/serve.mjs`) so that a missing or
 * unavailable package manager cannot stop the app from starting. Node is the
 * only thing this needs.
 */
import { fileURLToPath } from 'node:url';
import { runTypeScript } from './runtime.mjs';

const entry = fileURLToPath(new URL('../packages/server/src/main.ts', import.meta.url));
process.exit(runTypeScript(entry));
