import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import type { Api, ApiRequest } from './api.js';
import { originMatches } from './auth.js';
import { serveStatic, type StaticMount } from './static-files.js';

/**
 * HTTP transport.
 *
 * Thin by design: it reads the request, hands it to the router, and writes the
 * response. Every security decision — authentication, tenant binding, policy —
 * happens in the router, so nothing here can be bypassed by reaching the
 * transport differently.
 *
 * What did belong here, and was missing (audit SEC-7, PERF-8):
 *
 *  - response security headers. `content-security-policy`,
 *    `strict-transport-security`, `permissions-policy` and the cross-origin
 *    isolation headers were all absent, and `panel.html` — a page designed to
 *    be framed — had no `frame-ancestors` at all, so any site could embed a
 *    tenant's conversation panel;
 *  - server timeouts. `headersTimeout`, `requestTimeout` and `keepAliveTimeout`
 *    were unset, which leaves the process open to slowloris and to socket
 *    exhaustion;
 *  - a default deny on CORS. `*` plus a public key in page source let anyone
 *    drive a tenant's assistant from anywhere.
 */
export interface HttpServerOptions {
  readonly port?: number;
  readonly maxBodyBytes?: number;
  /**
   * Origins permitted to call the session API from a browser.
   *
   * `*` is accepted but no longer the default, and it is not the security
   * control in any case: origin binding happens at authentication, against the
   * tenant's registered origins (audit SEC-5).
   */
  readonly allowedOrigins?: readonly string[];
  /**
   * Directories served as static assets. Tried before the router, and only for
   * GET/HEAD against a real file with a known extension, so no API route can be
   * shadowed by a file on disk.
   */
  readonly staticMounts?: readonly StaticMount[];
  /** Emit HSTS. Off by default: sending it over plain HTTP locks out a dev box. */
  readonly hsts?: boolean;
  /** Frame-ancestors for the panel. Usually every tenant's registered origins. */
  readonly panelFrameAncestors?: readonly string[];
  /** Trust `x-forwarded-for` for the client address. Only behind a known proxy. */
  readonly trustProxy?: boolean;
  readonly timeouts?: {
    readonly headersMs?: number;
    readonly requestMs?: number;
    readonly keepAliveMs?: number;
  };
  /** Maximum simultaneous connections before new ones are refused. */
  readonly maxConnections?: number;
}

const DEFAULT_TIMEOUTS = { headersMs: 15_000, requestMs: 30_000, keepAliveMs: 5_000 };

export function createHttpServer(api: Api, options: HttpServerOptions = {}): Server {
  const maxBodyBytes = options.maxBodyBytes ?? 256 * 1024;
  const staticMounts = options.staticMounts ?? [];

  const server = createServer((request, response) => {
    void handle(api, request, response, maxBodyBytes, options, staticMounts);
  });

  // Slowloris and socket exhaustion are the two cheapest attacks against a
  // Node server, and both are closed by numbers rather than by code.
  const timeouts = { ...DEFAULT_TIMEOUTS, ...(options.timeouts ?? {}) };
  server.headersTimeout = timeouts.headersMs;
  server.requestTimeout = timeouts.requestMs;
  server.keepAliveTimeout = timeouts.keepAliveMs;
  // Node requires headersTimeout > keepAliveTimeout to avoid a race where a
  // connection is closed while a request is in flight.
  if (server.headersTimeout <= server.keepAliveTimeout) {
    server.headersTimeout = server.keepAliveTimeout + 1_000;
  }
  if (options.maxConnections) server.maxConnections = options.maxConnections;

  return server;
}

/**
 * Response security headers.
 *
 * The API and the panel need different policies: the API returns JSON and
 * should be frameable by nobody, while the panel is *designed* to be framed —
 * by the tenant's own site and nowhere else.
 */
export function securityHeaders(options: {
  readonly kind: 'api' | 'panel' | 'page' | 'asset';
  readonly hsts?: boolean;
  readonly frameAncestors?: readonly string[];
}): Record<string, string> {
  const headers: Record<string, string> = {
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'no-referrer',
    // No geolocation, camera, microphone or payment from any of our surfaces.
    'permissions-policy': 'accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()',
    'cross-origin-resource-policy': options.kind === 'api' ? 'same-origin' : 'cross-origin',
  };

  if (options.hsts) {
    headers['strict-transport-security'] = 'max-age=63072000; includeSubDomains; preload';
  }

  if (options.kind === 'panel' || options.kind === 'page') {
    const framing = options.kind === 'panel'
      ? (options.frameAncestors?.length ? options.frameAncestors.join(' ') : "'none'")
      // The console and the install page are ours and are never embedded.
      : "'none'";
    headers['content-security-policy'] = [
      "default-src 'self'",
      "base-uri 'none'",
      "form-action 'none'",
      "img-src 'self' data:",
      // No `'unsafe-inline'`: every style and script on our own pages is a
      // file on this origin, which is what makes the policy worth having
      // (audit SEC-7).
      "style-src 'self'",
      "script-src 'self'",
      "connect-src 'self'",
      "object-src 'none'",
      `frame-ancestors ${framing}`,
    ].join('; ');
    if (options.kind === 'page') headers['cross-origin-opener-policy'] = 'same-origin';
    return headers;
  }

  headers['content-security-policy'] = "default-src 'none'; frame-ancestors 'none'; base-uri 'none'";
  headers['cross-origin-opener-policy'] = 'same-origin';
  return headers;
}

async function handle(
  api: Api,
  request: IncomingMessage,
  response: ServerResponse,
  maxBodyBytes: number,
  options: HttpServerOptions,
  staticMounts: readonly StaticMount[],
): Promise<void> {
  const url = new URL(request.url ?? '/', 'http://localhost');
  const origin = request.headers.origin;
  const allowedOrigins = options.allowedOrigins ?? [];
  const allowOrigin = allowedOrigins.includes('*')
    ? '*'
    : (origin && originMatches(origin, allowedOrigins) ? origin : '');

  // The panel is designed to be framed by the tenant's own site; the console
  // and the install page are ours and are framed by nobody; everything else is
  // API JSON, which needs the strictest policy of the three.
  const kind = url.pathname.endsWith('/panel.html')
    ? 'panel' as const
    : (/\.(html|css|js|svg|png|jpe?g|webp|ico|woff2|txt|map)$/.test(url.pathname) || url.pathname === '/'
        ? 'page' as const
        : 'api' as const);
  const headers: Record<string, string> = {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    ...securityHeaders({
      kind,
      hsts: options.hsts,
      frameAncestors: options.panelFrameAncestors,
    }),
  };
  if (allowOrigin) {
    headers['access-control-allow-origin'] = allowOrigin;
    headers['access-control-allow-headers'] = 'authorization, content-type, x-correlation-id';
    headers['access-control-allow-methods'] = 'GET, POST, PATCH, DELETE, OPTIONS';
    headers['access-control-max-age'] = '600';
    headers['vary'] = 'origin';
  }

  if (request.method === 'OPTIONS') {
    response.writeHead(204, headers).end();
    return;
  }

  // Static assets are served before the router. `serveStatic` only answers for
  // a file that actually exists with a content type we recognise, so an API
  // path always falls through to the router below.
  if (staticMounts.length > 0 && (await serveStatic(staticMounts, request, response, headers))) {
    return;
  }

  let rawBody = '';
  try {
    rawBody = await readBody(request, maxBodyBytes);
  } catch {
    response.writeHead(413, headers).end(JSON.stringify({ error: 'SCHEMA_INVALID', message: 'Request body is too large.' }));
    return;
  }

  let body: unknown;
  if (rawBody.length > 0) {
    try {
      body = JSON.parse(rawBody);
    } catch {
      response.writeHead(400, headers).end(JSON.stringify({ error: 'SCHEMA_INVALID', message: 'Body must be JSON.' }));
      return;
    }
  }

  const apiRequest: ApiRequest = {
    method: request.method ?? 'GET',
    path: url.pathname,
    headers: request.headers as Record<string, string | undefined>,
    body,
    // The raw body is retained for webhook signature verification: a signature
    // is over the exact bytes sent, not over a re-serialised object.
    rawBody,
    query: Object.fromEntries(url.searchParams),
    ip: clientAddress(request, options.trustProxy === true),
  };

  const result = await api.handle(apiRequest);

  if (result.stream) {
    await writeEventStream(response, { ...headers, ...result.headers }, result.stream);
    return;
  }

  const payload = typeof result.body === 'string' ? result.body : JSON.stringify(result.body);
  response.writeHead(result.status, { ...headers, ...result.headers }).end(payload);
}

/**
 * Server-sent events (audit UX-2).
 *
 * Each chunk has already been validated by the orchestrator before it reaches
 * here; this writes bytes and nothing else. The comment ping on open defeats
 * proxies that buffer until the first newline, which is how a "streaming"
 * endpoint ends up arriving all at once.
 */
async function writeEventStream(
  response: ServerResponse,
  headers: Record<string, string>,
  stream: AsyncIterable<{ event: string; data: unknown }>,
): Promise<void> {
  response.writeHead(200, {
    ...headers,
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-store, no-transform',
    connection: 'keep-alive',
  });
  response.write(': open\n\n');

  try {
    for await (const chunk of stream) {
      if (response.writableEnded) break;
      response.write(`event: ${chunk.event}\ndata: ${JSON.stringify(chunk.data)}\n\n`);
    }
  } catch {
    if (!response.writableEnded) {
      response.write(`event: error\ndata: ${JSON.stringify({ message: 'The stream ended unexpectedly.' })}\n\n`);
    }
  } finally {
    if (!response.writableEnded) response.end();
  }
}

/**
 * Client address.
 *
 * `x-forwarded-for` is only read when the deployment says it sits behind a
 * proxy it controls. Trusting it by default would make the per-IP limiter
 * trivially defeatable by a header (audit SEC-2b).
 */
function clientAddress(request: IncomingMessage, trustProxy: boolean): string {
  if (trustProxy) {
    const forwarded = request.headers['x-forwarded-for'];
    const first = Array.isArray(forwarded) ? forwarded[0] : forwarded;
    const candidate = first?.split(',')[0]?.trim();
    if (candidate) return candidate;
  }
  return request.socket.remoteAddress ?? 'unknown';
}

function readBody(request: IncomingMessage, maxBytes: number): Promise<string> {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks: Buffer[] = [];
    request.on('data', (chunk: Buffer) => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(new Error('body too large'));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    request.on('error', reject);
  });
}
